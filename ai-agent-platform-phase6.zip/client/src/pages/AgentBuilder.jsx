import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import * as Icons from "lucide-react";
import { Card, Input, Textarea, Button } from "../components/ui/index.jsx";
import { BUILTIN_SKILLS } from "../lib/skills.js";
import { api } from "../lib/api.js";

const PERSONALITIES = ["Professional", "Friendly", "Creative", "Direct", "Custom"];

export default function AgentBuilder() {
  const navigate = useNavigate();
  const { id } = useParams(); // present when editing an existing agent
  const [form, setForm] = useState({ name: "", description: "", personality: "Professional", instructions: "" });
  const [skillIds, setSkillIds] = useState([]);
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(!id);
  const [error, setError] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  useEffect(() => {
    if (!id) return;
    api.get(`/agents/${id}`).then((a) => {
      setForm({
        name: a.name,
        description: a.description || "",
        personality: (a.personality || "professional").replace(/^\w/, (c) => c.toUpperCase()),
        instructions: a.instructions || "",
      });
      setSkillIds((a.skills || []).map((s) => s.id));
      setLoaded(true);
    }).catch(() => setLoaded(true));
  }, [id]);

  const toggleSkill = (skillId) => setSkillIds((s) => (s.includes(skillId) ? s.filter((x) => x !== skillId) : [...s, skillId]));

  const save = async () => {
    setError(""); setBusy(true);
    try {
      const payload = { ...form, personality: form.personality.toLowerCase(), skillIds };
      if (id) await api.patch(`/agents/${id}`, payload);
      else await api.post("/agents", payload);
      navigate("/app/agents");
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };

  if (!loaded) return null;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">{id ? "Edit agent" : "Agent Builder"}</h1>
        <p className="mt-1 text-muted">{id ? "Update this agent's behavior and enabled skills." : "Define how your agent behaves and what it can do."}</p>
      </div>

      <Card className="space-y-5 p-6">
        <Input label="Agent name" value={form.name} onChange={set("name")} placeholder="e.g. Marketing Assistant" />
        <Input label="Description" value={form.description} onChange={set("description")} placeholder="What is this agent for?" />

        <div>
          <span className="mb-1.5 block text-sm font-medium text-muted">Personality</span>
          <div className="flex flex-wrap gap-2">
            {PERSONALITIES.map((p) => (
              <button
                key={p}
                onClick={() => setForm({ ...form, personality: p })}
                className={`rounded-xl border px-3.5 py-2 text-sm ${form.personality === p ? "border-accent bg-accent/10 text-accent" : "border-line text-muted hover:text-ink"}`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <Textarea label="Instructions" rows={5} value={form.instructions} onChange={set("instructions")} placeholder="Tell your AI agent how it should behave." />
      </Card>

      <Card className="p-6">
        <h2 className="font-display font-semibold">Skills</h2>
        <p className="mt-1 text-sm text-muted">Select the capabilities this agent can use.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {BUILTIN_SKILLS.map((s) => {
            const Icon = Icons[s.icon] || Icons.Wrench;
            const on = skillIds.includes(s.id);
            return (
              <button
                key={s.id}
                onClick={() => toggleSkill(s.id)}
                className={`flex items-start gap-3 rounded-xl border p-4 text-left transition ${on ? "border-accent bg-accent/5" : "border-line hover:border-accent/40"}`}
              >
                <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${on ? "accent-gradient text-white" : "bg-elevated text-muted"}`}><Icon size={18} /></div>
                <div>
                  <div className="text-sm font-medium">{s.name}</div>
                  <div className="text-xs text-muted">{s.description}</div>
                </div>
              </button>
            );
          })}
        </div>
      </Card>

      {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-500">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => navigate("/app/agents")}>Cancel</Button>
        <Button onClick={save} disabled={busy || !form.name.trim()}>
          {busy ? (id ? "Saving…" : "Creating…") : id ? "Save changes" : "Create agent"}
        </Button>
      </div>
    </div>
  );
}
