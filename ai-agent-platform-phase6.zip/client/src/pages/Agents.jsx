import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Bot, Plus, Trash2 } from "lucide-react";
import { Card, Button, Badge, EmptyState } from "../components/ui/index.jsx";
import { api } from "../lib/api.js";

export default function Agents() {
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const load = () => api.get("/agents").then(setAgents).catch(() => {}).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const remove = async (id) => { await api.del(`/agents/${id}`); load(); };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">My Agents</h1>
          <p className="mt-1 text-muted">Agents you've built and their skills.</p>
        </div>
        <Button to="/app/agents/new"><Plus size={16} /> New agent</Button>
      </div>

      {loading ? null : agents.length === 0 ? (
        <EmptyState icon={Bot} title="No agents yet" description="Create your first agent — give it a personality, instructions, and a few skills." action={<Button to="/app/agents/new"><Plus size={16} /> Create an agent</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {agents.map((a) => (
            <Card key={a.id} className="p-5">
              <div className="flex items-start justify-between">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-accent/10 text-accent"><Bot size={20} /></div>
                <div className="flex gap-1">
                  <button onClick={() => navigate(`/app/agents/${a.id}/edit`)} className="rounded-lg px-2 py-1 text-xs font-medium text-muted hover:bg-elevated hover:text-ink">Edit</button>
                  <button onClick={() => remove(a.id)} className="rounded-lg p-1.5 text-muted hover:bg-elevated hover:text-red-500"><Trash2 size={16} /></button>
                </div>
              </div>
              <h3 className="mt-3 font-display font-semibold">{a.name}</h3>
              <p className="mt-1 line-clamp-2 text-sm text-muted">{a.description || "No description."}</p>
              <div className="mt-3 flex items-center gap-2">
                <Badge tone="accent">{a.personality}</Badge>
                <Badge tone="success">{a.status}</Badge>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
