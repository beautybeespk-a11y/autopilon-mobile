// Provider abstraction. The rest of the app never talks to a vendor directly;
// it calls chatComplete(), which routes to the configured provider.
import { anthropicChat } from "./providers/anthropic.js";
import { openaiChat } from "./providers/openai.js";
import { geminiChat } from "./providers/gemini.js";

const REGISTRY = {
  anthropic: { fn: anthropicChat, keyEnv: "ANTHROPIC_API_KEY", label: "Anthropic Claude" },
  openai:    { fn: openaiChat,    keyEnv: "OPENAI_API_KEY",    label: "OpenAI" },
  gemini:    { fn: geminiChat,    keyEnv: "GEMINI_API_KEY",    label: "Google Gemini" },
};

export function providerStatus() {
  const name = (process.env.AI_PROVIDER || "anthropic").toLowerCase();
  const entry = REGISTRY[name];
  if (!entry) return { configured: false, provider: name, reason: `Unknown provider "${name}"` };
  const hasKey = Boolean(process.env[entry.keyEnv]);
  return { configured: hasKey, provider: name, label: entry.label, reason: hasKey ? null : `${entry.keyEnv} is not set` };
}

// messages: [{ role: 'user'|'assistant'|'system', content: string }]
export async function chatComplete({ messages, systemPrompt }) {
  const status = providerStatus();
  if (!status.configured) {
    const err = new Error("AI provider not configured");
    err.code = "PROVIDER_NOT_CONFIGURED";
    err.detail = status.reason;
    throw err;
  }
  const entry = REGISTRY[status.provider];
  return entry.fn({ messages, systemPrompt, apiKey: process.env[entry.keyEnv] });
}
