import db from "../db.js";
import { runWorkflow } from "./runner.js";

// Called from anywhere an event happens that might be a workflow trigger:
// the WhatsApp webhook, the chat route, task creation, etc. Future trigger
// sources (a new integration's webhook, for instance) call this exact same
// function — nothing else in the app needs to change to support them.
export async function fireTrigger(userId, triggerType, context = {}) {
  const automations = db.prepare(
    "SELECT * FROM automations WHERE userId = ? AND triggerType = ? AND status = 'active'"
  ).all(userId, triggerType);

  const results = [];
  for (const automation of automations) {
    try {
      const result = await runWorkflow(automation.id, { userId, triggerSource: triggerType, initialVariables: context });
      results.push({ automationId: automation.id, ...result });
    } catch (err) {
      results.push({ automationId: automation.id, status: "failed", error: err.message });
    }
  }
  return results;
}
