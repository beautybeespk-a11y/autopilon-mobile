import db from "../db.js";
import { cryptoRandom, logActivity } from "../middleware.js";
import { registerTool } from "./registry.js";

registerTool({
  name: "create_memory",
  description: "Permanently stores a piece of information about the user for future conversations.",
  category: "memory",
  parameters: {
    type: "object",
    properties: {
      content: { type: "string" },
      type: { type: "string" },
    },
    required: ["content", "type"],
  },
  requiredPermissions: ["memory.write"],
  requiresConfirmation: true, // The AI must never save a memory without explicit approval.
  async execute(parameters, context) {
    const { userId } = context;
    const id = cryptoRandom();
    const now = new Date().toISOString();
    db.prepare("INSERT INTO memories (id, userId, content, type, createdAt) VALUES (?, ?, ?, ?, ?)")
      .run(id, userId, parameters.content, parameters.type || "note", now);
    logActivity(db, userId, "memory_created", `Saved a memory`);
    return { memoryId: id, content: parameters.content, type: parameters.type || "note" };
  },
});

registerTool({
  name: "list_memories",
  description: "Returns memories belonging to the authenticated user.",
  category: "memory",
  parameters: { type: "object", properties: {}, required: [] },
  requiredPermissions: ["memory.read"],
  requiresConfirmation: false,
  async execute(parameters, context) {
    const { userId } = context;
    const memories = db.prepare("SELECT id, content, type, createdAt FROM memories WHERE userId = ? ORDER BY createdAt DESC").all(userId);
    return { memories, count: memories.length };
  },
});

registerTool({
  name: "delete_memory",
  description: "Permanently deletes a memory belonging to the authenticated user.",
  category: "memory",
  parameters: {
    type: "object",
    properties: { memoryId: { type: "string" } },
    required: ["memoryId"],
  },
  requiredPermissions: ["memory.delete"],
  requiresConfirmation: true, // Deletion is irreversible; must be explicitly confirmed.
  async execute(parameters, context) {
    const { userId } = context;
    const owned = db.prepare("SELECT id FROM memories WHERE id = ? AND userId = ?").get(parameters.memoryId, userId);
    if (!owned) {
      const err = new Error("Memory not found or not owned by this user.");
      err.code = "NOT_FOUND";
      throw err;
    }
    db.prepare("DELETE FROM memories WHERE id = ? AND userId = ?").run(parameters.memoryId, userId);
    logActivity(db, userId, "memory_deleted", `Deleted a memory`);
    return { memoryId: parameters.memoryId, deleted: true };
  },
});
