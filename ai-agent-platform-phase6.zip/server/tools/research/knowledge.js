import db from "../../db.js";
import { cryptoRandom, logActivity } from "../../middleware.js";
import { registerTool } from "../registry.js";

// Single table backs the Knowledge Library. Reports, notes, saved URLs, and
// summaries are all "knowledge items" distinguished by `type` — one flexible
// table instead of four near-duplicate ones, since the fields (title,
// content, tags, sources, owner, date) are the same shape either way.

registerTool({
  name: "save_research",
  description: "Permanently saves a research report or note to the user's Knowledge Library.",
  category: "research",
  parameters: {
    type: "object",
    properties: {
      title: { type: "string" },
      category: { type: "string" },
      tags: { type: "array" },
      content: { type: "object" }, // the report object, or { note: "..." }
      sourceUrls: { type: "array" },
    },
    required: ["title", "content"],
  },
  requiredPermissions: ["knowledge.write"],
  requiresConfirmation: true, // Nothing is saved to the Knowledge Library without explicit approval.
  async execute(parameters, context) {
    const { userId } = context;
    const id = cryptoRandom();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO knowledge_items (id, userId, type, title, category, tags, content, sourceUrls, createdAt)
       VALUES (?, ?, 'report', ?, ?, ?, ?, ?, ?)`
    ).run(
      id, userId, parameters.title, parameters.category || "research",
      JSON.stringify(parameters.tags || []), JSON.stringify(parameters.content),
      JSON.stringify(parameters.sourceUrls || []), now
    );
    logActivity(db, userId, "research_saved", `Saved research: "${parameters.title}"`);
    return { itemId: id, title: parameters.title };
  },
});

registerTool({
  name: "search_knowledge",
  description: "Searches the authenticated user's saved Knowledge Library by keyword.",
  category: "research",
  parameters: {
    type: "object",
    properties: { query: { type: "string" } },
    required: ["query"],
  },
  requiredPermissions: ["knowledge.read"],
  requiresConfirmation: false,
  async execute(parameters, context) {
    const { userId } = context;
    const like = `%${parameters.query}%`;
    const rows = db.prepare(
      `SELECT id, title, category, tags, createdAt FROM knowledge_items
       WHERE userId = ? AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)
       ORDER BY createdAt DESC LIMIT 20`
    ).all(userId, like, like, like);
    return { query: parameters.query, items: rows.map((r) => ({ ...r, tags: JSON.parse(r.tags || "[]") })), count: rows.length };
  },
});

registerTool({
  name: "list_saved_research",
  description: "Lists everything the authenticated user has saved to their Knowledge Library.",
  category: "research",
  parameters: { type: "object", properties: {}, required: [] },
  requiredPermissions: ["knowledge.read"],
  requiresConfirmation: false,
  async execute(parameters, context) {
    const { userId } = context;
    const rows = db.prepare(
      "SELECT id, title, category, tags, createdAt FROM knowledge_items WHERE userId = ? ORDER BY createdAt DESC"
    ).all(userId);
    return { items: rows.map((r) => ({ ...r, tags: JSON.parse(r.tags || "[]") })), count: rows.length };
  },
});

registerTool({
  name: "delete_saved_research",
  description: "Permanently deletes an item from the authenticated user's Knowledge Library.",
  category: "research",
  parameters: {
    type: "object",
    properties: { itemId: { type: "string" } },
    required: ["itemId"],
  },
  requiredPermissions: ["knowledge.delete"],
  requiresConfirmation: true, // Deletion is irreversible; must be explicitly confirmed.
  async execute(parameters, context) {
    const { userId } = context;
    const owned = db.prepare("SELECT id FROM knowledge_items WHERE id = ? AND userId = ?").get(parameters.itemId, userId);
    if (!owned) {
      const err = new Error("Knowledge item not found or not owned by this user.");
      err.code = "NOT_FOUND";
      throw err;
    }
    db.prepare("DELETE FROM knowledge_items WHERE id = ? AND userId = ?").run(parameters.itemId, userId);
    logActivity(db, userId, "research_deleted", "Deleted a saved research item");
    return { itemId: parameters.itemId, deleted: true };
  },
});
