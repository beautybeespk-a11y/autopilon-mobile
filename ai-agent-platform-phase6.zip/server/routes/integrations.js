import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../middleware.js";
import { metaOAuthStatus } from "../integrations/meta/oauth.js";

const router = Router();
router.use(requireAuth);

// Catalog of integrations the platform will support. status here is the real,
// per-user connection status — nothing is faked as connected.
const CATALOG = [
  { provider: "meta_ads", name: "Meta Ads", note: "Priority integration", available: true, connectType: "redirect", connectPath: "/api/integrations/meta/connect" },
  { provider: "whatsapp", name: "WhatsApp Business", available: true, connectType: "manual" },
  { provider: "gmail", name: "Gmail", available: false },
  { provider: "google_calendar", name: "Google Calendar", available: false },
  { provider: "google_drive", name: "Google Drive", available: false },
  { provider: "wordpress", name: "WordPress", available: false },
  { provider: "woocommerce", name: "WooCommerce", available: false },
  { provider: "shopify", name: "Shopify", available: false },
  { provider: "slack", name: "Slack", available: false },
  { provider: "telegram", name: "Telegram", available: false },
];

router.get("/", (req, res) => {
  const mine = db.prepare("SELECT provider, status FROM integrations WHERE userId = ?").all(req.session.userId);
  const map = Object.fromEntries(mine.map((r) => [r.provider, r.status]));
  const metaStatus = metaOAuthStatus();
  const whatsappWebhookConfigured = Boolean(process.env.WHATSAPP_VERIFY_TOKEN && process.env.META_APP_SECRET);
  res.json(
    CATALOG.map((c) => ({
      ...c,
      status: map[c.provider] || "not_connected",
      // Meta Ads is "available" as a feature, but still needs the app owner
      // (you) to have set META_APP_ID/SECRET/REDIRECT_URI — surface that
      // distinction so the UI can explain rather than just fail on click.
      setupRequired:
        c.provider === "meta_ads" && !metaStatus.configured ? metaStatus.reason
        : c.provider === "whatsapp" && !whatsappWebhookConfigured ? "WHATSAPP_VERIFY_TOKEN and META_APP_SECRET must be set for incoming messages to work"
        : null,
    }))
  );
});

export default router;
