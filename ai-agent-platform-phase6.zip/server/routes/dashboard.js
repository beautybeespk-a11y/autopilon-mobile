import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../middleware.js";

const router = Router();
router.use(requireAuth);

router.get("/", (req, res) => {
  const uid = req.session.userId;
  const one = (sql) => db.prepare(sql).get(uid).c;
  res.json({
    activeAgents: one("SELECT COUNT(*) c FROM agents WHERE userId = ? AND status = 'active'"),
    availableSkills: db.prepare("SELECT COUNT(*) c FROM skills WHERE status = 'available'").get().c,
    connectedIntegrations: one("SELECT COUNT(*) c FROM integrations WHERE userId = ? AND status = 'connected'"),
    runningAutomations: 0,
    recentActivity: db.prepare("SELECT * FROM activity_logs WHERE userId = ? ORDER BY createdAt DESC LIMIT 6").all(uid),
  });
});

export default router;
