import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../middleware.js";
import { metaOAuthStatus } from "../integrations/meta/oauth.js";
import { googleOAuthStatus } from "../integrations/gmail/oauth.js";

const router = Router();
router.use(requireAuth);

// Catalog of integrations the platform will support. status here is the real,
// per-user connection status — nothing is faked as connected.
const CATALOG = [
  { provider: "meta_ads", name: "Meta Ads", note: "Priority integration", available: true, connectType: "redirect", connectPath: "/api/integrations/meta/connect" },
  { provider: "whatsapp", name: "WhatsApp Business", available: true, connectType: "manual" },
  { provider: "wordpress", name: "WordPress", available: true, connectType: "manual" },
  { provider: "woocommerce", name: "WooCommerce", available: true, connectType: "manual" },
  { provider: "gmail", name: "Gmail", available: true, connectType: "redirect", connectPath: "/api/integrations/gmail/connect" },
  // Registered in the Universal Integration SDK's scope for Phase 7, but not
  // fully implemented — see PHASE7_NOTES.md. Shown as "coming soon" rather
  // than hidden, since the SDK groundwork means adding real tools later is
  // a contained addition, not a rebuild.
  { provider: "google_calendar", name: "Google Calendar", available: false },
  { provider: "google_drive", name: "Google Drive", available: false },
  { provider: "google_docs", name: "Google Docs", available: false },
  { provider: "google_sheets", name: "Google Sheets", available: false },
  { provider: "shopify", name: "Shopify", available: false },
  { provider: "slack", name: "Slack", available: false },
  { provider: "telegram", name: "Telegram", available: false },
];

router.get("/", (req, res) => {
  const mine = db.prepare("SELECT provider, status FROM integrations WHERE userId = ?").all(req.session.userId);
  const map = Object.fromEntries(mine.map((r) => [r.provider, r.status]));
  const metaStatus = metaOAuthStatus();
  const gmailStatus = googleOAuthStatus();
  const whatsappWebhookConfigured = Boolean(process.env.WHATSAPP_VERIFY_TOKEN && process.env.META_APP_SECRET);
  res.json(
    CATALOG.map((c) => ({
      ...c,
      status: map[c.provider] || "not_connected",
      // Meta Ads/Gmail are "available" as features, but still need the app
      // owner (you) to have set the right env vars — surface that
      // distinction so the UI can explain rather than just fail on click.
      setupRequired:
        c.provider === "meta_ads" && !metaStatus.configured ? metaStatus.reason
        : c.provider === "gmail" && !gmailStatus.configured ? gmailStatus.reason
        : c.provider === "whatsapp" && !whatsappWebhookConfigured ? "WHATSAPP_VERIFY_TOKEN and META_APP_SECRET must be set for incoming messages to work"
        : null,
    }))
  );
});

export default router;
