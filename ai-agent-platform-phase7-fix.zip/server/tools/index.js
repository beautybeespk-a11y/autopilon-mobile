// Importing these runs their registerTool() calls as a side effect.
// Adding a new tool in Phase 3+ means: write the file, import it here.
import "./tasks.js";
import "./memory.js";
import "./research/webSearch.js";
import "./research/readWebpage.js";
import "./research/generateReport.js";
import "./research/knowledge.js";
import "./meta/campaigns.js";
import "./whatsapp/messaging.js";
import "./automation/draftWorkflow.js";
import "./wordpress/content.js";
import "./woocommerce/commerce.js";
import "./gmail/email.js";

export { listTools, listToolsForSkills, getTool } from "./registry.js";
