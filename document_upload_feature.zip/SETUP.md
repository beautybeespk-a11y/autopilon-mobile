# Real document uploads — setup

## 1. Install the new server dependencies

```bash
cd /workspaces/ai-factory/server
npm install multer pdf-parse mammoth
```

## 2. Install this zip's files

Unzip into the repo root so files land at the right paths:

```bash
cd /workspaces/ai-factory
unzip -o document_upload_feature.zip -d .
```

This overwrites:
- `server/routes/research.js` (adds upload + download endpoints)
- `client/src/lib/api.js` (adds multipart upload support)
- `client/src/pages/Knowledge.jsx` (real upload/download UI)

And adds:
- `server/tools/research/documentExtract.js` (new — PDF/DOCX/text extraction)

## 3. Keep uploaded files out of git

```bash
echo "server/uploads/" >> .gitignore
```

## 4. Restart the server

Whatever you normally do to restart it (e.g. if using `npm run dev` in `server/`,
just let the `--watch` flag pick up the change, or stop/restart it manually).

## 5. Rebuild the web client if it's served as a static build

If your setup serves a built `client/dist` (rather than the Vite dev server
proxying live), rebuild it:

```bash
cd /workspaces/ai-factory/client
npm run build
```

## What changed

- Uploading a file in Knowledge now actually uploads it — stored on the
  server under `server/uploads/knowledge/`, with a `knowledge_items` row
  (`type = 'document'`) created for it.
- Text is extracted from PDF, DOCX, TXT, MD, CSV, JSON, and LOG files and
  stored alongside the item — this makes it automatically searchable by
  your agents via the existing `search_knowledge` tool (no new agent tool
  needed, since that tool already does a `LIKE` search over the same
  `content` column).
- Other file types (images, `.doc`, spreadsheets, etc.) still upload and
  can be downloaded, but a note is shown that their content isn't
  text-searchable yet.
- Each document can be downloaded via a new download icon, and deleted —
  deleting also removes the file from disk.
- 15MB upload size limit per file.
