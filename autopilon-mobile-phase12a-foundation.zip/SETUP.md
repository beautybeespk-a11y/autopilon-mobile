# Autopilon Mobile — Phase 12A: Foundation

## What's in this zip
Only the `lib/` source folder and `pubspec.yaml` — **not** a full Flutter
project. I can't run `flutter create` in this sandbox (no Flutter SDK
here), so you'll generate the real, tool-verified native Android/iOS
scaffolding yourself with one command, then drop these files in.

## Setup (run these in order, in a terminal where `flutter` is installed)

```bash
# 1. Create the project (only if you haven't already)
flutter create autopilon_mobile
cd autopilon_mobile

# 2. Replace the generated pubspec.yaml and lib/ with the ones in this zip
#    (back up the generated pubspec.yaml first if you want to compare)

# 3. Install dependencies
flutter pub get

# 4. Edit lib/main.dart — set ApiClient.baseUrl to point at YOUR running
#    Autopilon server (see the comment right above `void main()` in that
#    file for the exact value depending on emulator vs physical device vs
#    Codespace).

# 5. Start your Autopilon server (in the web project, as usual):
#    npm start

# 6. Run the mobile app
flutter run
```

## What's built (Phase 12A)
- **Auth**: login, signup, forgot password — all calling your existing
  `server/routes/auth.js` endpoints exactly as they are, no backend changes.
- **Session handling**: the backend uses cookie-based sessions
  (express-session), same as the web client. Rather than adding a parallel
  token-auth system to the backend, this app carries a real, persistent
  cookie jar — the same thing a browser does. Login sets the cookie, and
  every request after that sends it back automatically.
- **"Remember me"**: on app start, the app tries the stored cookie against
  `GET /auth/me` — if it's still valid, you land straight on the home
  screen, no login prompt.
- **Theme**: exact color/font match with the web client (same hex values
  from `client/src/index.css`, same Space Grotesk/Inter font families via
  Google Fonts), light and dark, following the device's system setting.
- **Navigation**: `go_router` with an auth guard — trying to reach any
  screen while logged out redirects to `/login`; being logged in and
  landing on `/login` redirects you to `/`.
- **Organization switching**: same "Personal (no organization)" + per-org
  list model as the web client, calling the same
  `/api/organizations` / `/api/organizations/switch` endpoints.

## Honest limitations
- **Untested by me** — I have no Flutter SDK, no emulator, no device in
  this sandbox. Every file passed a manual brace/paren balance check and
  import-resolution check, which is the most I can verify without the real
  toolchain. It needs a real `flutter run` on your end before either of us
  can call it working.
- **No app icon / splash screen customization yet** — using Flutter's
  defaults. That's App Store Readiness (Phase 12E) territory.
- **Home screen is a placeholder** — confirms you're logged in and shows
  your name; the real dashboard (agents, tasks, usage, billing summary) is
  Phase 12B, once this foundation is confirmed working on your end.

## Test checklist for you to run through
- [ ] `flutter pub get` succeeds with no errors
- [ ] `flutter run` builds and launches (Android emulator, iOS simulator,
      or a real device)
- [ ] Sign up with a new account — lands on the home screen
- [ ] Log out — redirected to login
- [ ] Log back in with the same account — lands on home screen again
- [ ] Fully close and reopen the app — still logged in (session restore)
- [ ] If you have an organization: tap the org switcher in the top bar,
      switch to it, switch back to Personal
- [ ] Toggle your device's dark/light mode — app follows it
