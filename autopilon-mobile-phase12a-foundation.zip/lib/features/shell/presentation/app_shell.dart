import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../organizations/presentation/organization_switcher_sheet.dart';
import '../../organizations/providers/organization_provider.dart';
import '../../auth/providers/auth_provider.dart';

/// The persistent frame for the authenticated part of the app — top bar
/// (app name + org switcher + logout) and a bottom nav. Phase 12A only has
/// Home; Phase 12B adds Chat/Agents/Projects/Notifications tabs here.
class AppShell extends ConsumerWidget {
  const AppShell({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orgState = ref.watch(organizationControllerProvider);
    final activeOrgName = orgState.activeOrgId == null
        ? 'Personal'
        : orgState.organizations.where((o) => o.id == orgState.activeOrgId).map((o) => o.name).firstOrNull ?? '...';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Autopilon'),
        actions: [
          TextButton.icon(
            onPressed: () => showOrganizationSwitcher(context),
            icon: const Icon(Icons.swap_horiz, size: 18),
            label: Text(activeOrgName, overflow: TextOverflow.ellipsis),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Log out',
            onPressed: () => ref.read(authControllerProvider.notifier).logout(),
          ),
        ],
      ),
      body: child,
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
