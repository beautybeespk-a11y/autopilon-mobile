import { Router } from "express";
import db from "../db.js";
import { requireAuth, cryptoRandom, logActivity } from "../middleware.js";
import { providerStatus } from "../ai/provider.js";
import { orchestrate } from "../orchestrator/index.js";

const router = Router();
router.use(requireAuth);

router.get("/provider-status", (req, res) => res.json(providerStatus()));

// List conversations for the signed-in user
router.get("/conversations", (req, res) => {
  const rows = db.prepare(
    "SELECT id, title, agentId, createdAt, updatedAt FROM conversations WHERE userId = ? ORDER BY updatedAt DESC"
  ).all(req.session.userId);
  res.json(rows);
});

router.get("/conversations/:id/messages", (req, res) => {
  const conv = db.prepare("SELECT * FROM conversations WHERE id = ? AND userId = ?").get(req.params.id, req.session.userId);
  if (!conv) return res.status(404).json({ error: "Conversation not found" });
  const msgs = db.prepare("SELECT id, role, content, createdAt, meta FROM messages WHERE conversationId = ? ORDER BY createdAt ASC").all(conv.id);
  const parsed = msgs.map((m) => ({ ...m, meta: m.meta ? JSON.parse(m.meta) : null }));
  res.json({ conversation: conv, messages: parsed });
});

// Send a message. Creates a conversation if none supplied.
router.post("/message", async (req, res) => {
  const { conversationId, content, agentId } = req.body || {};
  if (!content?.trim()) return res.status(400).json({ error: "Message content is required." });
  const now = new Date().toISOString();
  const userId = req.session.userId;

  let convId = conversationId;
  if (!convId) {
    convId = cryptoRandom();
    const title = content.slice(0, 48);
    db.prepare("INSERT INTO conversations (id, userId, agentId, title, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)")
      .run(convId, userId, agentId || null, title, now, now);
    logActivity(db, userId, "conversation_started", `Started "${title}"`);
  } else {
    const owns = db.prepare("SELECT id FROM conversations WHERE id = ? AND userId = ?").get(convId, userId);
    if (!owns) return res.status(404).json({ error: "Conversation not found" });
  }

  db.prepare("INSERT INTO messages (id, conversationId, role, content, createdAt) VALUES (?, ?, 'user', ?, ?)")
    .run(cryptoRandom(), convId, content, now);

  // Build system prompt from the selected agent, if any.
  let systemPrompt = "You are a helpful AI assistant inside the AI Agent Platform.";
  if (agentId) {
    const agent = db.prepare("SELECT * FROM agents WHERE id = ? AND userId = ?").get(agentId, userId);
    if (agent) {
      systemPrompt = `You are "${agent.name}". Personality: ${agent.personality}. ${agent.instructions || ""}`.trim();
    }
  }

  // Tool results from earlier turns are stored in messages.meta but the AI's
  // own reply text often doesn't repeat every ID it returned (e.g. it may
  // show "BeautyBees – Website Sales" without the numeric campaign ID). A
  // follow-up like "get insights for that campaign" needs the real ID, so
  // fold prior toolResults into history rather than passing role+content alone.
  const rawHistory = db.prepare("SELECT role, content, meta FROM messages WHERE conversationId = ? ORDER BY createdAt ASC").all(convId);
  const history = rawHistory.map((m) => {
    if (m.role !== "assistant" || !m.meta) return { role: m.role, content: m.content };
    const parsedMeta = JSON.parse(m.meta);
    const successes = (parsedMeta.toolResults || []).filter((r) => !r.error);
    if (!successes.length) return { role: m.role, content: m.content };
    const dataNote = successes.map((r) => `${r.toolName} returned: ${JSON.stringify(r.result)}`).join("\n");
    return { role: m.role, content: `${m.content}\n\n[Underlying tool data from this turn, for your own reference in follow-ups — do not repeat verbatim: ${dataNote}]` };
  });

  try {
    const { reply, trace, toolResults, confirmation } = await orchestrate({
      userId,
      agentId: agentId || null,
      conversationId: convId,
      userMessage: content,
      history,
      agentSystemPrompt: systemPrompt,
    });
    const replyAt = new Date().toISOString();
    const meta = JSON.stringify({ trace, toolResults, confirmation });
    db.prepare("INSERT INTO messages (id, conversationId, role, content, createdAt, meta) VALUES (?, ?, 'assistant', ?, ?, ?)")
      .run(cryptoRandom(), convId, reply, replyAt, meta);
    db.prepare("UPDATE conversations SET updatedAt = ? WHERE id = ?").run(replyAt, convId);
    res.json({ conversationId: convId, reply, trace, toolResults, confirmation });
  } catch (err) {
    if (err.code === "PROVIDER_NOT_CONFIGURED") {
      return res.status(503).json({ error: "AI provider not configured", detail: err.detail, conversationId: convId });
    }
    res.status(502).json({ error: "The AI provider returned an error.", detail: err.message, conversationId: convId });
  }
});

export default router;
