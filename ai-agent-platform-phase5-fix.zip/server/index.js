import "dotenv/config";
import express from "express";
import session from "express-session";
import cors from "cors";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import fs from "fs";

import "./db.js";
import "./tools/index.js"; // side-effect: registers all tools with the Tool Registry
import authRoutes from "./routes/auth.js";
import chatRoutes from "./routes/chat.js";
import agentRoutes from "./routes/agents.js";
import skillRoutes from "./routes/skills.js";
import integrationRoutes from "./routes/integrations.js";
import taskRoutes from "./routes/tasks.js";
import activityRoutes from "./routes/activity.js";
import dashboardRoutes from "./routes/dashboard.js";
import "./integrations/meta/index.js"; // side-effect: registers the Meta integration definition
import "./integrations/whatsapp/index.js"; // side-effect: registers the WhatsApp integration definition
import confirmationRoutes from "./routes/confirmations.js";
import researchRoutes from "./routes/research.js";
import metaAuthRoutes from "./routes/metaAuth.js";
import whatsappAuthRoutes from "./routes/whatsappAuth.js";
import whatsappWebhookRoutes from "./routes/whatsappWebhook.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;

// The `verify` callback stashes the raw bytes before JSON parsing — needed
// to verify Meta's webhook HMAC signature, which is computed over the exact
// raw body, not a re-serialized version of the parsed object.
app.use(express.json({ limit: "2mb", verify: (req, res, buf) => { req.rawBody = buf; } }));

// In dev the client runs on :5173 and proxies /api, so CORS with credentials
// is only needed if you point the client at the server cross-origin.
app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN || true,
    credentials: true,
  })
);

app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev-insecure-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 1000 * 60 * 60 * 24 * 7,
    },
  })
);

app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use("/api/auth", authRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/agents", agentRoutes);
app.use("/api/skills", skillRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/confirmations", confirmationRoutes);
app.use("/api/research", researchRoutes);
// These must be mounted BEFORE the general "/api/integrations" catalog route
// below — Express matches by path PREFIX, so that catalog router (which
// requires login for every request reaching it) would otherwise intercept
// anything starting with "/api/integrations", including the public webhook,
// before this more specific router ever got a chance to run.
app.use("/api/integrations/meta", metaAuthRoutes);
app.use("/api/integrations/whatsapp", whatsappWebhookRoutes);
app.use("/api/integrations/whatsapp", whatsappAuthRoutes);
app.use("/api/integrations", integrationRoutes);

// Serve the built client in production (single-service deploy).
const clientDist = join(__dirname, "..", "client", "dist");
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api")) return res.status(404).json({ error: "Not found" });
    res.sendFile(join(clientDist, "index.html"));
  });
}

app.listen(PORT, () => {
  console.log(`AI Agent Platform API running on http://localhost:${PORT}`);
});
