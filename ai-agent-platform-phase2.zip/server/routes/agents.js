import { Router } from "express";
import db from "../db.js";
import { requireAuth, cryptoRandom, logActivity } from "../middleware.js";

const router = Router();
router.use(requireAuth);

router.get("/", (req, res) => {
  const agents = db.prepare("SELECT * FROM agents WHERE userId = ? ORDER BY updatedAt DESC").all(req.session.userId);
  res.json(agents);
});

router.get("/:id", (req, res) => {
  const agent = db.prepare("SELECT * FROM agents WHERE id = ? AND userId = ?").get(req.params.id, req.session.userId);
  if (!agent) return res.status(404).json({ error: "Agent not found" });
  const skills = db.prepare(
    "SELECT s.* FROM skills s JOIN agent_skills a ON a.skillId = s.id WHERE a.agentId = ?"
  ).all(agent.id);
  res.json({ ...agent, skills });
});

router.post("/", (req, res) => {
  const { name, description, instructions, personality, skillIds } = req.body || {};
  if (!name?.trim()) return res.status(400).json({ error: "Agent name is required." });
  const id = cryptoRandom();
  const now = new Date().toISOString();
  db.prepare(
    "INSERT INTO agents (id, userId, name, description, instructions, personality, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)"
  ).run(id, req.session.userId, name, description || "", instructions || "", personality || "professional", now, now);
  if (Array.isArray(skillIds)) {
    const link = db.prepare("INSERT OR IGNORE INTO agent_skills (agentId, skillId) VALUES (?, ?)");
    for (const sid of skillIds) link.run(id, sid);
  }
  logActivity(db, req.session.userId, "agent_created", `Created agent "${name}"`);
  res.json({ id });
});

router.delete("/:id", (req, res) => {
  const r = db.prepare("DELETE FROM agents WHERE id = ? AND userId = ?").run(req.params.id, req.session.userId);
  if (!r.changes) return res.status(404).json({ error: "Agent not found" });
  res.json({ ok: true });
});

export default router;
