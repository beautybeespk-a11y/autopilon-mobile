import { useState } from "react";
import { Upload, FileText, Search } from "lucide-react";
import { Card, Input, EmptyState, Badge } from "../components/ui/index.jsx";

// Phase 1: UI + local file staging only. Document processing (parsing,
// chunking, embeddings) is added in a later phase, so files show as "pending".
export default function Knowledge() {
  const [files, setFiles] = useState([]);
  const [query, setQuery] = useState("");

  const onFiles = (list) => {
    const added = Array.from(list).map((f) => ({ id: crypto.randomUUID(), name: f.name, size: f.size, status: "pending" }));
    setFiles((prev) => [...added, ...prev]);
  };

  const shown = files.filter((f) => f.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Knowledge</h1>
        <p className="mt-1 text-muted">Upload documents your agents can reference. Supported later: PDF, DOCX, TXT, CSV, images.</p>
      </div>

      <label
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => { e.preventDefault(); onFiles(e.dataTransfer.files); }}
        className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-line bg-surface/50 px-6 py-12 text-center hover:border-accent/50"
      >
        <div className="mb-3 grid h-12 w-12 place-items-center rounded-xl bg-accent/10 text-accent"><Upload size={24} /></div>
        <span className="font-medium">Drop files here or click to upload</span>
        <span className="mt-1 text-sm text-muted">Files are staged now; processing is enabled in a later phase.</span>
        <input type="file" multiple className="hidden" onChange={(e) => onFiles(e.target.files)} />
      </label>

      <div className="relative">
        <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
        <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search files" className="pl-10" />
      </div>

      {shown.length === 0 ? (
        <EmptyState icon={FileText} title="No files yet" description="Upload a document to build your knowledge base." />
      ) : (
        <Card className="divide-y divide-line">
          {shown.map((f) => (
            <div key={f.id} className="flex items-center justify-between px-5 py-3">
              <div className="flex items-center gap-3">
                <FileText size={18} className="text-muted" />
                <span className="text-sm font-medium">{f.name}</span>
                <span className="font-mono text-xs text-muted">{(f.size / 1024).toFixed(0)} KB</span>
              </div>
              <Badge tone="warn">Pending</Badge>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
