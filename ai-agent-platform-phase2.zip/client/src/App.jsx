import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import Landing from "./pages/Landing.jsx";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";

import Dashboard from "./pages/Dashboard.jsx";
import Chat from "./pages/Chat.jsx";
import Agents from "./pages/Agents.jsx";
import AgentBuilder from "./pages/AgentBuilder.jsx";
import Skills from "./pages/Skills.jsx";
import Automations from "./pages/Automations.jsx";
import Integrations from "./pages/Integrations.jsx";
import Knowledge from "./pages/Knowledge.jsx";
import Tasks from "./pages/Tasks.jsx";
import Activity from "./pages/Activity.jsx";
import Settings from "./pages/Settings.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      <Route
        path="/app"
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="chat" element={<Chat />} />
        <Route path="agents" element={<Agents />} />
        <Route path="agents/new" element={<AgentBuilder />} />
        <Route path="skills" element={<Skills />} />
        <Route path="automations" element={<Automations />} />
        <Route path="integrations" element={<Integrations />} />
        <Route path="knowledge" element={<Knowledge />} />
        <Route path="tasks" element={<Tasks />} />
        <Route path="activity" element={<Activity />} />
        <Route path="settings" element={<Settings />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
