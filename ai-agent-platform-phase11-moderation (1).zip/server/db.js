import Database from "better-sqlite3";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const db = new Database(join(__dirname, "app.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// --- Schema. Extend by adding tables/columns; keep migrations additive. ---
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL UNIQUE,
  password   TEXT NOT NULL,
  avatar     TEXT,
  createdAt  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agents (
  id           TEXT PRIMARY KEY,
  userId       TEXT NOT NULL,
  name         TEXT NOT NULL,
  description  TEXT,
  instructions TEXT,
  personality  TEXT DEFAULT 'professional',
  status       TEXT DEFAULT 'active',
  createdAt    TEXT NOT NULL,
  updatedAt    TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_agents_user ON agents(userId);

CREATE TABLE IF NOT EXISTS skills (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT,
  category    TEXT,
  status      TEXT DEFAULT 'available'
);

CREATE TABLE IF NOT EXISTS agent_skills (
  agentId TEXT NOT NULL,
  skillId TEXT NOT NULL,
  PRIMARY KEY (agentId, skillId),
  FOREIGN KEY (agentId) REFERENCES agents(id) ON DELETE CASCADE,
  FOREIGN KEY (skillId) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conversations (
  id         TEXT PRIMARY KEY,
  userId     TEXT NOT NULL,
  agentId    TEXT,
  title      TEXT NOT NULL DEFAULT 'New conversation',
  createdAt  TEXT NOT NULL,
  updatedAt  TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(userId);

CREATE TABLE IF NOT EXISTS messages (
  id             TEXT PRIMARY KEY,
  conversationId TEXT NOT NULL,
  role           TEXT NOT NULL,
  content        TEXT NOT NULL,
  createdAt      TEXT NOT NULL,
  FOREIGN KEY (conversationId) REFERENCES conversations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversationId);

CREATE TABLE IF NOT EXISTS memories (
  id        TEXT PRIMARY KEY,
  userId    TEXT NOT NULL,
  content   TEXT NOT NULL,
  type      TEXT DEFAULT 'note',
  createdAt TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_mem_user ON memories(userId);

CREATE TABLE IF NOT EXISTS integrations (
  id        TEXT PRIMARY KEY,
  userId    TEXT NOT NULL,
  provider  TEXT NOT NULL,
  status    TEXT DEFAULT 'not_connected',
  createdAt TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_int_user ON integrations(userId);

CREATE TABLE IF NOT EXISTS tasks (
  id          TEXT PRIMARY KEY,
  userId      TEXT NOT NULL,
  title       TEXT NOT NULL,
  description TEXT,
  status      TEXT DEFAULT 'todo',
  priority    TEXT DEFAULT 'medium',
  dueDate     TEXT,
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(userId);

CREATE TABLE IF NOT EXISTS activity_logs (
  id          TEXT PRIMARY KEY,
  userId      TEXT NOT NULL,
  action      TEXT NOT NULL,
  description TEXT,
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_act_user ON activity_logs(userId);

-- ---- Phase 2: Orchestrator / Tool execution ----

CREATE TABLE IF NOT EXISTS execution_plans (
  id             TEXT PRIMARY KEY,
  userId         TEXT NOT NULL,
  conversationId TEXT,
  goal           TEXT,
  status         TEXT NOT NULL DEFAULT 'planning', -- planning|running|completed|failed
  createdAt      TEXT NOT NULL,
  updatedAt      TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_plans_user ON execution_plans(userId);

CREATE TABLE IF NOT EXISTS tool_executions (
  id             TEXT PRIMARY KEY,
  planId         TEXT,
  userId         TEXT NOT NULL,
  conversationId TEXT,
  toolName       TEXT NOT NULL,
  parameters     TEXT, -- JSON string; never store secrets here
  status         TEXT NOT NULL DEFAULT 'pending', -- pending|planning|awaiting_confirmation|running|completed|failed
  result         TEXT, -- JSON string
  error          TEXT,
  startedAt      TEXT,
  completedAt    TEXT,
  createdAt      TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (planId) REFERENCES execution_plans(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_exec_user ON tool_executions(userId);
CREATE INDEX IF NOT EXISTS idx_exec_plan ON tool_executions(planId);

CREATE TABLE IF NOT EXISTS confirmation_requests (
  id          TEXT PRIMARY KEY,
  executionId TEXT NOT NULL,
  userId      TEXT NOT NULL,
  toolName    TEXT NOT NULL,
  reason      TEXT,
  status      TEXT NOT NULL DEFAULT 'pending', -- pending|approved|rejected|expired
  createdAt   TEXT NOT NULL,
  resolvedAt  TEXT,
  expiresAt   TEXT NOT NULL,
  FOREIGN KEY (executionId) REFERENCES tool_executions(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_confirm_user ON confirmation_requests(userId);
CREATE INDEX IF NOT EXISTS idx_confirm_exec ON confirmation_requests(executionId);

-- Per-agent skill→permission grants. Phase 1 seeded agent_skills already
-- controls which skills an agent has; this table is for future per-agent
-- permission overrides. Not required for Phase 2's default (skill grants
-- imply its tools' permissions) but present so the schema doesn't need
-- another migration when fine-grained control is added.
CREATE TABLE IF NOT EXISTS agent_permissions (
  agentId    TEXT NOT NULL,
  permission TEXT NOT NULL,
  PRIMARY KEY (agentId, permission),
  FOREIGN KEY (agentId) REFERENCES agents(id) ON DELETE CASCADE
);

-- ---- Phase 3: Web research & Knowledge Library ----
-- One flexible table backs the Knowledge Library (reports, notes, saved
-- URLs, summaries) — same shape (title/content/tags/sources/owner/date)
-- regardless of type, so one table with a discriminator beats four
-- near-duplicate ones. "Research History" is served by the tool_executions
-- table already built in Phase 2 (every web_search/read_webpage/etc. call
-- is already logged there per user, per conversation, with a timestamp).
CREATE TABLE IF NOT EXISTS knowledge_items (
  id         TEXT PRIMARY KEY,
  userId     TEXT NOT NULL,
  type       TEXT NOT NULL DEFAULT 'report', -- report|note|url|summary|article
  title      TEXT NOT NULL,
  category   TEXT,
  tags       TEXT, -- JSON array
  content    TEXT, -- JSON: report object or { note }
  sourceUrls TEXT, -- JSON array of { title, url }
  createdAt  TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_knowledge_user ON knowledge_items(userId);
`);

// Additive migration: messages.meta stores JSON trace/toolResults for
// assistant messages so the ToolActivity rail survives a page refresh.
const messageCols = db.prepare("PRAGMA table_info(messages)").all().map((c) => c.name);
if (!messageCols.includes("meta")) {
  db.exec("ALTER TABLE messages ADD COLUMN meta TEXT");
}

// Additive migration: OAuth token storage for Phase 4 integrations. Tokens
// live only here, only on the server — never sent to the frontend.
const integrationCols = db.prepare("PRAGMA table_info(integrations)").all().map((c) => c.name);
const addIntegrationCol = (name, type) => {
  if (!integrationCols.includes(name)) db.exec(`ALTER TABLE integrations ADD COLUMN ${name} ${type}`);
};
addIntegrationCol("accessToken", "TEXT");
addIntegrationCol("refreshToken", "TEXT");
addIntegrationCol("tokenExpiresAt", "TEXT");
addIntegrationCol("scopes", "TEXT");  // JSON array
addIntegrationCol("meta", "TEXT");    // JSON — e.g. selected ad account id
addIntegrationCol("updatedAt", "TEXT");
db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_int_user_provider ON integrations(userId, provider)");

// ---- Phase 5: WhatsApp Business ----
// Connection state (token, phone_number_id, WABA id, business name, settings)
// reuses the `integrations` table (provider='whatsapp') exactly like Meta
// Ads does — no separate whatsapp_accounts table needed, same reasoning as
// every "one flexible table" decision in earlier phases.
db.exec(`
CREATE TABLE IF NOT EXISTS whatsapp_conversations (
  id             TEXT PRIMARY KEY,
  userId         TEXT NOT NULL,
  contactPhone   TEXT NOT NULL,
  conversationId TEXT NOT NULL, -- links to the existing conversations table, so
                                 -- WhatsApp and web chat share one history
  createdAt      TEXT NOT NULL,
  lastMessageAt  TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (conversationId) REFERENCES conversations(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_wa_conv_user_phone ON whatsapp_conversations(userId, contactPhone);

CREATE TABLE IF NOT EXISTS whatsapp_messages (
  id          TEXT PRIMARY KEY,
  messageId   TEXT,           -- links to the existing messages table (nullable — status
                               -- events reference a wa message that may arrive before content)
  waMessageId TEXT,
  direction   TEXT NOT NULL,  -- inbound|outbound
  type        TEXT,
  status      TEXT,           -- sent|delivered|read|failed
  createdAt   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wa_msg_wamessageid ON whatsapp_messages(waMessageId);

-- Dedupes webhook deliveries — Meta can and does redeliver the same event.
CREATE TABLE IF NOT EXISTS webhook_events (
  id         TEXT PRIMARY KEY, -- the WhatsApp message/status id, so a redelivery collides here
  eventType  TEXT NOT NULL,
  receivedAt TEXT NOT NULL
);
`);

// ---- Phase 6: Automation & Workflow Engine ----
// Workflow variables (spec's `workflow_variables`) are deliberately not a
// separate table — a run's live variable state is a JSON blob on
// automation_runs, and default/initial values are a JSON blob on
// automations. Both are read/written as a whole per step, never queried
// column-by-column, so a normalized table would add joins without adding
// capability — same reasoning as every other "flexible JSON column" call
// made in earlier phases.
db.exec(`
CREATE TABLE IF NOT EXISTS automations (
  id            TEXT PRIMARY KEY,
  userId        TEXT NOT NULL,
  name          TEXT NOT NULL,
  description   TEXT,
  status        TEXT NOT NULL DEFAULT 'draft', -- draft|active|paused
  triggerType   TEXT NOT NULL, -- manual|schedule|webhook|whatsapp_message|meta_ads_event|ai_chat_request|knowledge_update|task_due
  triggerConfig TEXT,          -- JSON — e.g. { frequency, cron, timezone, hour, minute }
  variables     TEXT,          -- JSON — default/initial variables for a new run
  agentId       TEXT,          -- which agent's permissions/skills gate this workflow's tool calls
  createdAt     TEXT NOT NULL,
  updatedAt     TEXT NOT NULL,
  lastRunAt     TEXT,
  nextRunAt     TEXT,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_automations_user ON automations(userId);
CREATE INDEX IF NOT EXISTS idx_automations_trigger ON automations(triggerType, status);

CREATE TABLE IF NOT EXISTS automation_steps (
  id            TEXT PRIMARY KEY,
  automationId  TEXT NOT NULL,
  stepOrder     INTEGER NOT NULL,
  type          TEXT NOT NULL, -- condition|ai_decision|action|delay|approval|loop|end
  config        TEXT,          -- JSON — shape depends on type, see automation/runner.js
  createdAt     TEXT NOT NULL,
  FOREIGN KEY (automationId) REFERENCES automations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_steps_automation ON automation_steps(automationId, stepOrder);

CREATE TABLE IF NOT EXISTS automation_runs (
  id             TEXT PRIMARY KEY,
  automationId   TEXT NOT NULL,
  userId         TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'pending', -- pending|running|awaiting_approval|completed|failed|cancelled
  triggerSource  TEXT,   -- what actually fired this run (manual|schedule|whatsapp_message|...)
  variables      TEXT,   -- JSON — live variable state for this run
  currentStep    INTEGER DEFAULT 0,
  error          TEXT,
  retryCount     INTEGER DEFAULT 0,
  startedAt      TEXT,
  endedAt        TEXT,
  createdAt      TEXT NOT NULL,
  FOREIGN KEY (automationId) REFERENCES automations(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_runs_automation ON automation_runs(automationId, createdAt);
CREATE INDEX IF NOT EXISTS idx_runs_user ON automation_runs(userId);

CREATE TABLE IF NOT EXISTS automation_logs (
  id        TEXT PRIMARY KEY,
  runId     TEXT NOT NULL,
  stepOrder INTEGER,
  stepType  TEXT,
  status    TEXT NOT NULL, -- started|completed|failed|skipped
  detail    TEXT,          -- JSON
  createdAt TEXT NOT NULL,
  FOREIGN KEY (runId) REFERENCES automation_runs(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_logs_run ON automation_logs(runId, createdAt);

-- Starter templates users can clone into a real automation. Seeded once below.
CREATE TABLE IF NOT EXISTS workflow_templates (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  description   TEXT,
  category      TEXT,
  triggerType   TEXT NOT NULL,
  triggerConfig TEXT,
  steps         TEXT NOT NULL -- JSON array of { type, config }, applied in order on clone
);

-- ---- Phase 6.5: Event-Driven Automation ----
-- Every published event lands here first — this IS the event history the
-- spec asks for, and its unique (source, eventId) index is the dedup
-- mechanism: a redelivered webhook or a repeated Meta/WhatsApp callback
-- collides on insert and is silently skipped, exactly like Phase 5's
-- webhook_events table did for WhatsApp alone. This generalizes that same
-- pattern to every event source.
CREATE TABLE IF NOT EXISTS automation_events (
  id                  TEXT PRIMARY KEY,
  userId              TEXT NOT NULL,
  source              TEXT NOT NULL, -- whatsapp|meta_ads|internal|webhook|schedule
  eventType           TEXT NOT NULL, -- e.g. whatsapp_message, campaign_paused, task_created
  eventId             TEXT,          -- source's own id for this event, when it has one
  payload             TEXT,          -- JSON — the variables this event exposes
  matchedAutomations  TEXT,          -- JSON array of automation ids this event matched
  status              TEXT NOT NULL DEFAULT 'received', -- received|queued|processed
  createdAt           TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_events_dedupe ON automation_events(source, eventId);
CREATE INDEX IF NOT EXISTS idx_events_user ON automation_events(userId, createdAt);

-- The execution queue. Workflows are never run directly inside a webhook
-- handler — an event enqueues one row per matched automation here, and a
-- background tick processes them. This is an in-process, DB-backed queue
-- (no Redis/BullMQ in this stack) — durable across a restart, but not
-- distributed. See PHASE6.5_NOTES.md for what that does and doesn't cover.
CREATE TABLE IF NOT EXISTS automation_event_queue (
  id            TEXT PRIMARY KEY,
  eventId       TEXT NOT NULL,
  automationId  TEXT NOT NULL,
  userId        TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'queued', -- queued|processing|completed|failed|dead_letter
  attempts      INTEGER NOT NULL DEFAULT 0,
  lastError     TEXT,
  createdAt     TEXT NOT NULL,
  processedAt   TEXT,
  FOREIGN KEY (eventId) REFERENCES automation_events(id) ON DELETE CASCADE,
  FOREIGN KEY (automationId) REFERENCES automations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_queue_status ON automation_event_queue(status, createdAt);
`);

// Additive migration: link approvals to an automation run, so workflow
// approval steps reuse the exact same confirmation_requests table and
// approve/reject UI built in Phase 2 — no parallel approval system.
const confirmCols = db.prepare("PRAGMA table_info(confirmation_requests)").all().map((c) => c.name);
if (!confirmCols.includes("automationRunId")) {
  db.exec("ALTER TABLE confirmation_requests ADD COLUMN automationRunId TEXT");
}

// --- Phase 8: Agent Manager core — extends the existing `agents` table
// rather than replacing it. `version` increments on every edit; the actual
// history of what changed lives in `agent_versions` below, so `agents`
// itself only ever needs to hold current state.
const agentCols = db.prepare("PRAGMA table_info(agents)").all().map((c) => c.name);
if (!agentCols.includes("avatar")) db.exec("ALTER TABLE agents ADD COLUMN avatar TEXT");
if (!agentCols.includes("category")) db.exec("ALTER TABLE agents ADD COLUMN category TEXT DEFAULT 'general'");
if (!agentCols.includes("version")) db.exec("ALTER TABLE agents ADD COLUMN version INTEGER NOT NULL DEFAULT 1");
if (!agentCols.includes("aiProvider")) db.exec("ALTER TABLE agents ADD COLUMN aiProvider TEXT"); // NULL = platform default (AI_PROVIDER env)
if (!agentCols.includes("aiModel")) db.exec("ALTER TABLE agents ADD COLUMN aiModel TEXT"); // NULL = that provider's default model
if (!agentCols.includes("orgId")) db.exec("ALTER TABLE agents ADD COLUMN orgId TEXT"); // NULL = personal agent (default, unchanged behavior)
if (!agentCols.includes("workspaceId")) db.exec("ALTER TABLE agents ADD COLUMN workspaceId TEXT"); // set only when scoped to one workspace, not the whole org

const execCols = db.prepare("PRAGMA table_info(tool_executions)").all().map((c) => c.name);
if (!execCols.includes("agentId")) db.exec("ALTER TABLE tool_executions ADD COLUMN agentId TEXT");

// Phase 9: Shared Automations — same additive pattern as Shared Agents.
// A user who never touches organizations keeps every automation exactly
// as "Personal" (orgId NULL), unchanged from before this migration.
const automationCols = db.prepare("PRAGMA table_info(automations)").all().map((c) => c.name);
if (!automationCols.includes("orgId")) db.exec("ALTER TABLE automations ADD COLUMN orgId TEXT");
if (!automationCols.includes("workspaceId")) db.exec("ALTER TABLE automations ADD COLUMN workspaceId TEXT");
if (!automationCols.includes("version")) db.exec("ALTER TABLE automations ADD COLUMN version INTEGER NOT NULL DEFAULT 1");

db.exec(`
CREATE TABLE IF NOT EXISTS automation_versions (
  id            TEXT PRIMARY KEY,
  automationId  TEXT NOT NULL,
  version       INTEGER NOT NULL,
  snapshot      TEXT NOT NULL, -- JSON: {name, description, triggerType, triggerConfig, variables, agentId, orgId, workspaceId, steps}
  note          TEXT,
  createdAt     TEXT NOT NULL,
  FOREIGN KEY (automationId) REFERENCES automations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_automation_versions_automation ON automation_versions(automationId);
`);

// Phase 9: Shared Integrations. users.activeOrgId is the persisted (not
// just session-only) "which org am I currently operating in" flag — this
// lets getConnection() resolve org context from userId alone, so the 80+
// existing tool call sites (getConnection(userId, provider)) don't need to
// change at all to benefit from org-shared connections. integrations.orgId
// marks a connection row as org-owned; NULL (the default, unchanged for
// every existing row) means personal, exactly as before this migration.
const userCols = db.prepare("PRAGMA table_info(users)").all().map((c) => c.name);
if (!userCols.includes("activeOrgId")) db.exec("ALTER TABLE users ADD COLUMN activeOrgId TEXT");
if (!userCols.includes("isPlatformAdmin")) db.exec("ALTER TABLE users ADD COLUMN isPlatformAdmin INTEGER NOT NULL DEFAULT 0");
if (!userCols.includes("stripeCustomerId")) db.exec("ALTER TABLE users ADD COLUMN stripeCustomerId TEXT"); // for personal Marketplace purchases — distinct from the per-org subscription customer

const integrationOrgCols = db.prepare("PRAGMA table_info(integrations)").all().map((c) => c.name);
if (!integrationOrgCols.includes("orgId")) db.exec("ALTER TABLE integrations ADD COLUMN orgId TEXT");

// Phase 9: Projects. Belong to a workspace. Rather than adding a projectId
// column to five different existing tables (tasks, agents, knowledge_items,
// automations, conversations), one generic link table records "this project
// includes this item" — additive, and each existing table stays untouched.
db.exec(`
CREATE TABLE IF NOT EXISTS projects (
  id          TEXT PRIMARY KEY,
  workspaceId TEXT NOT NULL,
  name        TEXT NOT NULL,
  description TEXT,
  status      TEXT NOT NULL DEFAULT 'active', -- active | archived
  createdAt   TEXT NOT NULL,
  updatedAt   TEXT NOT NULL,
  FOREIGN KEY (workspaceId) REFERENCES workspaces(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_projects_workspace ON projects(workspaceId);

CREATE TABLE IF NOT EXISTS project_items (
  id        TEXT PRIMARY KEY,
  projectId TEXT NOT NULL,
  itemType  TEXT NOT NULL, -- task | agent | knowledge | automation | conversation
  itemId    TEXT NOT NULL,
  addedAt   TEXT NOT NULL,
  FOREIGN KEY (projectId) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_project_item_unique ON project_items(projectId, itemType, itemId);
`);

// Phase 9: Audit Logs. Extends the existing activity_logs table (used since
// Phase 1) rather than creating a parallel table — same events, richer
// context. All four new columns are nullable/defaulted, so every existing
// logActivity(db, userId, action, description) call site (there are many)
// keeps working exactly as before, just without the new fields populated
// unless the caller opts in to the richer form.
const activityCols = db.prepare("PRAGMA table_info(activity_logs)").all().map((c) => c.name);
if (!activityCols.includes("orgId")) db.exec("ALTER TABLE activity_logs ADD COLUMN orgId TEXT");
if (!activityCols.includes("workspaceId")) db.exec("ALTER TABLE activity_logs ADD COLUMN workspaceId TEXT");
if (!activityCols.includes("ip")) db.exec("ALTER TABLE activity_logs ADD COLUMN ip TEXT");
if (!activityCols.includes("result")) db.exec("ALTER TABLE activity_logs ADD COLUMN result TEXT NOT NULL DEFAULT 'success'"); // success | failure

// --- Phase 9: Collaboration — comments (with @mentions), task assignment,
// and a real Notification Center. All additive; a user who never uses any
// of this sees an empty notification list and untouched task behavior. ---
const taskCols = db.prepare("PRAGMA table_info(tasks)").all().map((c) => c.name);
if (!taskCols.includes("assignedToUserId")) db.exec("ALTER TABLE tasks ADD COLUMN assignedToUserId TEXT");

db.exec(`
CREATE TABLE IF NOT EXISTS comments (
  id              TEXT PRIMARY KEY,
  entityType      TEXT NOT NULL, -- task | project | automation | agent | knowledge
  entityId        TEXT NOT NULL,
  authorUserId    TEXT NOT NULL,
  content         TEXT NOT NULL,
  mentionedUserIds TEXT NOT NULL DEFAULT '[]', -- JSON array, resolved from @mentions at write time
  createdAt       TEXT NOT NULL,
  FOREIGN KEY (authorUserId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_comments_entity ON comments(entityType, entityId);

CREATE TABLE IF NOT EXISTS notifications (
  id        TEXT PRIMARY KEY,
  userId    TEXT NOT NULL,
  type      TEXT NOT NULL, -- mention | assignment | approval | automation_failure | integration_error | org_invitation
  title     TEXT NOT NULL,
  body      TEXT,
  link      TEXT,          -- client-side path to navigate to, e.g. /app/tasks
  read      INTEGER NOT NULL DEFAULT 0,
  createdAt TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(userId, read);
`);

// --- Phase 10: Billing, Subscriptions & Usage ---
// Deliberate design boundary, consistent with every prior phase: billing is
// entirely organization-scoped. A user with no organization has no
// subscription, no quotas, no usage tracking — personal/individual mode
// stays completely unmetered, exactly as it's always been. Orgs are the
// billable unit, matching the spec's own "Organization Billing" section.
db.exec(`
CREATE TABLE IF NOT EXISTS plans (
  id                TEXT PRIMARY KEY, -- 'free' | 'starter' | 'professional' | 'business' | 'enterprise'
  name              TEXT NOT NULL,
  monthlyPriceCents INTEGER NOT NULL DEFAULT 0,
  maxUsers          INTEGER,          -- NULL = unlimited
  maxAgents         INTEGER,
  maxAutomations    INTEGER,
  maxIntegrations   INTEGER,
  maxAiRequests     INTEGER,          -- per billing period
  apiAccess         INTEGER NOT NULL DEFAULT 0,
  marketplaceAccess INTEGER NOT NULL DEFAULT 0,
  stripePriceId     TEXT,             -- Stripe Price object id; NULL = not checkout-able (e.g. Free, Enterprise)
  createdAt         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id                 TEXT PRIMARY KEY,
  orgId              TEXT NOT NULL UNIQUE,
  planId             TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'active', -- trialing | active | past_due | canceled
  billingMode        TEXT NOT NULL DEFAULT 'platform_managed', -- platform_managed | byok
  trialEndsAt        TEXT,
  currentPeriodStart TEXT NOT NULL,
  currentPeriodEnd   TEXT NOT NULL,
  cancelAtPeriodEnd  INTEGER NOT NULL DEFAULT 0,
  stripeCustomerId     TEXT,
  stripeSubscriptionId TEXT,
  createdAt          TEXT NOT NULL,
  updatedAt          TEXT NOT NULL,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE,
  FOREIGN KEY (planId) REFERENCES plans(id)
);

-- Raw event-level usage log — one row per metered event. Kept separate from
-- the rollup table below so nothing is ever lost even if the rollup logic
-- changes later; the rollup is a derived cache, this is the source of truth.
CREATE TABLE IF NOT EXISTS usage_records (
  id        TEXT PRIMARY KEY,
  orgId     TEXT NOT NULL,
  type      TEXT NOT NULL, -- ai_request | prompt_tokens | completion_tokens | automation_execution | tool_call | api_call
  quantity  INTEGER NOT NULL DEFAULT 1,
  metadata  TEXT,           -- JSON: e.g. { provider, model, toolName }
  createdAt TEXT NOT NULL,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_usage_org_period ON usage_records(orgId, createdAt);

-- Per-org, per-billing-period rollup — what quota checks actually read, so
-- checking a quota never means scanning the full usage_records history.
CREATE TABLE IF NOT EXISTS organization_usage (
  orgId               TEXT NOT NULL,
  period              TEXT NOT NULL, -- 'YYYY-MM'
  aiRequests          INTEGER NOT NULL DEFAULT 0,
  promptTokens        INTEGER NOT NULL DEFAULT 0,
  completionTokens    INTEGER NOT NULL DEFAULT 0,
  automationExecutions INTEGER NOT NULL DEFAULT 0,
  toolCalls           INTEGER NOT NULL DEFAULT 0,
  apiCalls            INTEGER NOT NULL DEFAULT 0,
  updatedAt           TEXT NOT NULL,
  PRIMARY KEY (orgId, period)
);

-- BYOK. Keys are AES-256-GCM encrypted at rest (see orchestrator/apiKeys.js)
-- — the raw key is never stored, logged, or returned by any API response.
CREATE TABLE IF NOT EXISTS api_keys (
  id            TEXT PRIMARY KEY,
  orgId         TEXT NOT NULL,
  provider      TEXT NOT NULL, -- openai | anthropic | gemini
  encryptedKey  TEXT NOT NULL, -- iv:authTag:ciphertext, all hex
  createdAt     TEXT NOT NULL,
  updatedAt     TEXT NOT NULL,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_api_keys_org_provider ON api_keys(orgId, provider);

-- Platform-issued coupons (trials, discounts). Created by a platform admin
-- (see users.isPlatformAdmin), redeemed by any org owner/admin for their
-- own org. Discount coupons record the intended discount for the eventual
-- Stripe checkout flow to apply — no real charge exists yet to discount.
CREATE TABLE IF NOT EXISTS coupon_codes (
  id             TEXT PRIMARY KEY,
  code           TEXT NOT NULL UNIQUE,
  type           TEXT NOT NULL, -- trial | percent_discount | fixed_discount
  value          INTEGER NOT NULL, -- trial: days; percent_discount: 0-100; fixed_discount: cents
  targetPlanId   TEXT,           -- for trial coupons: which plan the trial is on; NULL = current plan
  maxRedemptions INTEGER,        -- NULL = unlimited
  redemptionCount INTEGER NOT NULL DEFAULT 0,
  expiresAt      TEXT,
  active         INTEGER NOT NULL DEFAULT 1,
  createdBy      TEXT NOT NULL,
  createdAt      TEXT NOT NULL,
  FOREIGN KEY (createdBy) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS coupon_redemptions (
  id         TEXT PRIMARY KEY,
  couponId   TEXT NOT NULL,
  orgId      TEXT NOT NULL,
  redeemedAt TEXT NOT NULL,
  FOREIGN KEY (couponId) REFERENCES coupon_codes(id) ON DELETE CASCADE,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_coupon_redemption_unique ON coupon_redemptions(couponId, orgId);

-- Populated by the Stripe webhook handler (invoice.paid /
-- invoice.payment_failed) — never written to directly by any user action,
-- since these mirror what Stripe itself says happened.
CREATE TABLE IF NOT EXISTS invoices (
  id              TEXT PRIMARY KEY,
  orgId           TEXT NOT NULL,
  stripeInvoiceId TEXT NOT NULL UNIQUE,
  amountCents     INTEGER NOT NULL,
  status          TEXT NOT NULL, -- paid | open | void | uncollectible
  invoiceNumber   TEXT,
  pdfUrl          TEXT,
  periodStart     TEXT,
  periodEnd       TEXT,
  createdAt       TEXT NOT NULL,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_invoices_org ON invoices(orgId);

-- Dedupes quota-threshold notifications — without this, every single quota
-- check above 50% would fire another notification, which would be useless
-- noise. One row per (org, billing period, quota type, threshold) means
-- "already warned this org about this quota crossing this line this month."
CREATE TABLE IF NOT EXISTS quota_warnings_sent (
  orgId     TEXT NOT NULL,
  period    TEXT NOT NULL,
  quotaType TEXT NOT NULL,
  threshold INTEGER NOT NULL, -- 50 | 75 | 90 | 100
  sentAt    TEXT NOT NULL,
  PRIMARY KEY (orgId, period, quotaType, threshold)
);

-- Local audit trail for credit grants — the running balance is just
-- SUM(amountCents) for an org. When Stripe is configured, a grant is also
-- applied as a real Stripe Customer Balance transaction (see
-- stripeService.applyCustomerBalance) so it actually reduces what they owe;
-- this table is what survives regardless of whether that sync succeeds, and
-- is the only source of truth when Stripe isn't connected at all.
CREATE TABLE IF NOT EXISTS organization_credits (
  id           TEXT PRIMARY KEY,
  orgId        TEXT NOT NULL,
  amountCents  INTEGER NOT NULL, -- positive = credit granted
  reason       TEXT,
  grantedBy    TEXT NOT NULL,
  stripeSynced INTEGER NOT NULL DEFAULT 0,
  createdAt    TEXT NOT NULL,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE,
  FOREIGN KEY (grantedBy) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_org_credits_org ON organization_credits(orgId);

-- Phase 11: Marketplace Core + Publishing. Scoped to the four asset types
-- that are already fully data-driven in this codebase (agent configs,
-- automation configs, prompt text, and knowledge item bundles) — none of
-- them need new execution infrastructure to exist as a catalog entry.
-- "Skill"/"Plugin"/"Integration Connector" assets need the Developer SDK
-- (a later Phase 11 slice) to mean anything beyond a name in a list.
CREATE TABLE IF NOT EXISTS marketplace_categories (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  description TEXT,
  createdAt   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS marketplace_assets (
  id                   TEXT PRIMARY KEY,
  creatorUserId        TEXT NOT NULL,
  assetType            TEXT NOT NULL, -- agent | automation | prompt | knowledge_pack
  name                 TEXT NOT NULL,
  slug                 TEXT NOT NULL UNIQUE,
  description          TEXT,
  categoryId           TEXT,
  tags                 TEXT NOT NULL DEFAULT '[]', -- JSON array
  pricingType          TEXT NOT NULL DEFAULT 'free', -- free | one_time | subscription
  priceCents           INTEGER NOT NULL DEFAULT 0,
  license              TEXT,
  visibility           TEXT NOT NULL DEFAULT 'public', -- public | unlisted | private
  status               TEXT NOT NULL DEFAULT 'draft', -- draft | published | unpublished
  currentVersionId     TEXT,
  platformVersionNote  TEXT, -- free-text compatibility note; no real platform-version scheme exists to check against yet
  downloadCount        INTEGER NOT NULL DEFAULT 0,
  ratingSum            INTEGER NOT NULL DEFAULT 0,
  ratingCount          INTEGER NOT NULL DEFAULT 0,
  createdAt            TEXT NOT NULL,
  updatedAt            TEXT NOT NULL,
  FOREIGN KEY (creatorUserId) REFERENCES users(id),
  FOREIGN KEY (categoryId) REFERENCES marketplace_categories(id)
);
CREATE INDEX IF NOT EXISTS idx_marketplace_assets_creator ON marketplace_assets(creatorUserId);
CREATE INDEX IF NOT EXISTS idx_marketplace_assets_status ON marketplace_assets(status, visibility);
CREATE INDEX IF NOT EXISTS idx_marketplace_assets_type ON marketplace_assets(assetType);

-- One row per published version — the manifest is the actual asset
-- content (agent config, automation steps, prompt text, or knowledge item
-- bundle), shaped differently depending on assetType. Snapshotted at
-- publish time, not a live link back to the source agent/automation, so
-- editing your own agent later doesn't retroactively change what people
-- already installed.
CREATE TABLE IF NOT EXISTS asset_versions (
  id           TEXT PRIMARY KEY,
  assetId      TEXT NOT NULL,
  version      TEXT NOT NULL, -- semver-ish string, e.g. '1.0.0'
  releaseNotes TEXT,
  manifest     TEXT NOT NULL, -- JSON, shape depends on assetType
  createdAt    TEXT NOT NULL,
  FOREIGN KEY (assetId) REFERENCES marketplace_assets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_asset_versions_asset ON asset_versions(assetId);

-- Tracks what got installed, from which version, and what REAL entity it
-- created (an actual agent/automation row, or knowledge_items rows) — this
-- is what update/rollback/enable/disable/uninstall operate on. Installing
-- never creates a parallel "marketplace copy" of anything; it always
-- creates the same kind of row a normal create action would, through the
-- same creation functions (agentManager.createAgent, automation
-- engine.createAutomation, knowledge_items inserts).
CREATE TABLE IF NOT EXISTS marketplace_installs (
  id                  TEXT PRIMARY KEY,
  assetId             TEXT NOT NULL,
  installedVersionId  TEXT NOT NULL,
  installedByUserId   TEXT NOT NULL,
  installedEntityType TEXT NOT NULL, -- agent | automation | knowledge_item
  installedEntityIds  TEXT NOT NULL, -- JSON array — usually one id, multiple for a knowledge_pack
  status              TEXT NOT NULL DEFAULT 'active', -- active | disabled | uninstalled
  createdAt           TEXT NOT NULL,
  updatedAt           TEXT NOT NULL,
  FOREIGN KEY (assetId) REFERENCES marketplace_assets(id) ON DELETE CASCADE,
  FOREIGN KEY (installedByUserId) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_marketplace_installs_user ON marketplace_installs(installedByUserId);
CREATE INDEX IF NOT EXISTS idx_marketplace_installs_asset ON marketplace_installs(assetId);

-- Phase 11: Ratings & Reviews. One review per (asset, user) — reviewing
-- again edits the existing one rather than creating a duplicate. Rating
-- aggregates on marketplace_assets (ratingSum/ratingCount) are recomputed
-- from this table directly on every write, not maintained incrementally,
-- since review writes are rare and a direct recompute can never drift out
-- of sync the way an increment/decrement dance could.
CREATE TABLE IF NOT EXISTS asset_reviews (
  id               TEXT PRIMARY KEY,
  assetId          TEXT NOT NULL,
  userId           TEXT NOT NULL,
  rating           INTEGER NOT NULL, -- 1-5
  reviewText       TEXT,
  developerReply   TEXT,
  developerReplyAt TEXT,
  helpfulCount     INTEGER NOT NULL DEFAULT 0,
  createdAt        TEXT NOT NULL,
  updatedAt        TEXT NOT NULL,
  FOREIGN KEY (assetId) REFERENCES marketplace_assets(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_asset_reviews_unique ON asset_reviews(assetId, userId);
CREATE INDEX IF NOT EXISTS idx_asset_reviews_asset ON asset_reviews(assetId);

CREATE TABLE IF NOT EXISTS asset_review_votes (
  reviewId TEXT NOT NULL,
  userId   TEXT NOT NULL,
  createdAt TEXT NOT NULL,
  PRIMARY KEY (reviewId, userId)
);

-- Phase 11: Payments. Only one-time purchases are supported — Stripe
-- Checkout can price a one-time payment dynamically (price_data) with no
-- pre-created Price object, so a creator never has to touch the Stripe
-- dashboard. Subscription-priced assets would need a real Stripe Price
-- object per asset (Checkout can't do dynamic recurring prices) — that's a
-- disclosed scope cut, not built here.
CREATE TABLE IF NOT EXISTS asset_purchases (
  id                      TEXT PRIMARY KEY,
  assetId                 TEXT NOT NULL,
  buyerUserId             TEXT NOT NULL,
  sellerUserId            TEXT NOT NULL,
  amountCents             INTEGER NOT NULL,
  platformCommissionCents INTEGER NOT NULL,
  sellerNetCents          INTEGER NOT NULL,
  stripeCheckoutSessionId TEXT UNIQUE,
  status                  TEXT NOT NULL DEFAULT 'completed', -- completed | refunded
  createdAt               TEXT NOT NULL,
  FOREIGN KEY (assetId) REFERENCES marketplace_assets(id) ON DELETE CASCADE,
  FOREIGN KEY (buyerUserId) REFERENCES users(id),
  FOREIGN KEY (sellerUserId) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_asset_purchases_buyer ON asset_purchases(buyerUserId);
CREATE INDEX IF NOT EXISTS idx_asset_purchases_seller ON asset_purchases(sellerUserId);
CREATE UNIQUE INDEX IF NOT EXISTS idx_asset_purchases_buyer_asset ON asset_purchases(buyerUserId, assetId);

-- Phase 11: Moderation. Abuse reports — any user can file one; platform
-- admins resolve or dismiss.
CREATE TABLE IF NOT EXISTS asset_reports (
  id           TEXT PRIMARY KEY,
  assetId      TEXT NOT NULL,
  reporterUserId TEXT NOT NULL,
  reason       TEXT NOT NULL,
  details      TEXT,
  status       TEXT NOT NULL DEFAULT 'open', -- open | resolved | dismissed
  resolvedBy   TEXT,
  resolvedAt   TEXT,
  createdAt    TEXT NOT NULL,
  FOREIGN KEY (assetId) REFERENCES marketplace_assets(id) ON DELETE CASCADE,
  FOREIGN KEY (reporterUserId) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_asset_reports_status ON asset_reports(status);
`);

// moderationStatus defaults to 'approved' — every asset published before
// Moderation existed stays exactly as visible as it always was. Only NEW
// publishes (from here forward) actually enter the 'pending' review queue;
// see marketplace.js's setAssetStatus.
const marketplaceAssetCols = db.prepare("PRAGMA table_info(marketplace_assets)").all().map((c) => c.name);
if (!marketplaceAssetCols.includes("moderationStatus")) db.exec("ALTER TABLE marketplace_assets ADD COLUMN moderationStatus TEXT NOT NULL DEFAULT 'approved'");
if (!marketplaceAssetCols.includes("moderationNote")) db.exec("ALTER TABLE marketplace_assets ADD COLUMN moderationNote TEXT");

const seedCategories = [
  ["marketing", "Marketing", "Campaign planning, ad copy, content agents and automations."],
  ["sales", "Sales", "Lead handling, outreach, and pipeline automations."],
  ["support", "Customer Support", "Support agents, ticket automations, response templates."],
  ["ecommerce", "E-commerce", "Store management for WooCommerce, Shopify, and similar."],
  ["seo", "SEO & Content", "Content writing, SEO research, and publishing workflows."],
  ["productivity", "Productivity", "General task, email, and workflow automation."],
  ["analytics", "Analytics & Reporting", "Business analysis and reporting agents/automations."],
  ["developer", "Developer Tools", "Automation building blocks and technical workflows."],
];
const insertCategory = db.prepare("INSERT OR IGNORE INTO marketplace_categories (id, name, slug, description, createdAt) VALUES (?, ?, ?, ?, ?)");
for (const [slug, name, description] of seedCategories) {
  insertCategory.run(slug, name, slug, description, new Date().toISOString());
}

// Seed the five plans from the spec (idempotent — INSERT OR IGNORE so
// re-running never clobbers an admin's manual price/limit edits).
// Migrate existing plans/subscriptions rows (CREATE TABLE IF NOT EXISTS above
// only affects a fresh database — anyone who already has these tables from
// an earlier phase needs the new Stripe columns added explicitly).
const planCols = db.prepare("PRAGMA table_info(plans)").all().map((c) => c.name);
if (!planCols.includes("stripePriceId")) db.exec("ALTER TABLE plans ADD COLUMN stripePriceId TEXT");

const subCols = db.prepare("PRAGMA table_info(subscriptions)").all().map((c) => c.name);
if (!subCols.includes("stripeCustomerId")) db.exec("ALTER TABLE subscriptions ADD COLUMN stripeCustomerId TEXT");
if (!subCols.includes("stripeSubscriptionId")) db.exec("ALTER TABLE subscriptions ADD COLUMN stripeSubscriptionId TEXT");

const seedPlans = [
  ["free", "Free", 0, 3, 2, 3, 1, 50, 0, 0],
  ["starter", "Starter", 2900, 10, 10, 10, 5, 500, 0, 0],
  ["professional", "Professional", 9900, 25, 30, 30, 20, 2500, 1, 0],
  ["business", "Business", 29900, 100, 100, 100, 100, 10000, 1, 1],
  ["enterprise", "Enterprise", 0, null, null, null, null, null, 1, 1], // NULL = unlimited; enterprise pricing is custom (0 = "contact us"), not a real $0 plan
];
const insertPlan = db.prepare(
  `INSERT OR IGNORE INTO plans (id, name, monthlyPriceCents, maxUsers, maxAgents, maxAutomations, maxIntegrations, maxAiRequests, apiAccess, marketplaceAccess, createdAt)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
);
for (const [id, name, price, maxUsers, maxAgents, maxAutomations, maxIntegrations, maxAiRequests, apiAccess, marketplaceAccess] of seedPlans) {
  insertPlan.run(id, name, price, maxUsers, maxAgents, maxAutomations, maxIntegrations, maxAiRequests, apiAccess, marketplaceAccess, new Date().toISOString());
}

// --- Phase 8: per-agent memory isolation + knowledge sharing controls.
// agentId/ownerAgentId is nullable — NULL means "general", created outside
// any specific agent's context (e.g. plain chat), and stays visible to every
// agent exactly as all memories/knowledge were before this migration. Only
// an item explicitly owned by one agent AND marked 'private' becomes
// invisible to other agents — so nothing existing changes behavior.
const memCols = db.prepare("PRAGMA table_info(memories)").all().map((c) => c.name);
if (!memCols.includes("agentId")) db.exec("ALTER TABLE memories ADD COLUMN agentId TEXT");
if (!memCols.includes("visibility")) db.exec("ALTER TABLE memories ADD COLUMN visibility TEXT NOT NULL DEFAULT 'shared'");

const knowledgeCols = db.prepare("PRAGMA table_info(knowledge_items)").all().map((c) => c.name);
if (!knowledgeCols.includes("ownerAgentId")) db.exec("ALTER TABLE knowledge_items ADD COLUMN ownerAgentId TEXT");
if (!knowledgeCols.includes("visibility")) db.exec("ALTER TABLE knowledge_items ADD COLUMN visibility TEXT NOT NULL DEFAULT 'shared'");
if (!knowledgeCols.includes("editable")) db.exec("ALTER TABLE knowledge_items ADD COLUMN editable TEXT NOT NULL DEFAULT 'editable'"); // 'editable' | 'read_only' — only meaningful when visibility = 'shared'

// Phase 9: cross-USER sharing (org/workspace), layered on top of the
// Phase 8 columns above which govern sharing between one account's OWN
// agents. These are independent concerns — a knowledge item can be
// 'shared' among your own agents (Phase 8) while still being 'private'
// across other people (Phase 9), or vice versa. Defaults are the most
// restrictive (private, read_only), so nothing existing becomes newly
// visible to other accounts just from this migration running.
if (!knowledgeCols.includes("orgId")) db.exec("ALTER TABLE knowledge_items ADD COLUMN orgId TEXT");
if (!knowledgeCols.includes("workspaceId")) db.exec("ALTER TABLE knowledge_items ADD COLUMN workspaceId TEXT");
if (!knowledgeCols.includes("crossUserVisibility")) db.exec("ALTER TABLE knowledge_items ADD COLUMN crossUserVisibility TEXT NOT NULL DEFAULT 'private'"); // private|workspace|organization|public
if (!knowledgeCols.includes("crossUserEditable")) db.exec("ALTER TABLE knowledge_items ADD COLUMN crossUserEditable TEXT NOT NULL DEFAULT 'read_only'"); // editable|read_only — only meaningful when crossUserVisibility isn't 'private'

// --- Phase 9: Organizations, Workspaces, RBAC core ---
// Nothing existing is touched by this — a user who never creates or joins
// an organization keeps working exactly as before ("personal mode").
// Organization scoping for agents/knowledge/automations/integrations is a
// deliberately separate, later slice — this just lays the foundation.
db.exec(`
CREATE TABLE IF NOT EXISTS organizations (
  id        TEXT PRIMARY KEY,
  name      TEXT NOT NULL,
  logoUrl   TEXT,
  ownerId   TEXT NOT NULL,
  status    TEXT NOT NULL DEFAULT 'active', -- active | suspended
  settings  TEXT NOT NULL DEFAULT '{}',      -- JSON, org-level preferences
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL,
  FOREIGN KEY (ownerId) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS organization_members (
  id           TEXT PRIMARY KEY,
  orgId        TEXT NOT NULL,
  userId       TEXT,          -- NULL until an invitation is matched/accepted
  invitedEmail TEXT,          -- set for invitations; kept even after userId is filled in, for history
  role         TEXT NOT NULL DEFAULT 'member', -- owner | admin | manager | member | viewer | <custom role id>
  status       TEXT NOT NULL DEFAULT 'active', -- active | invited | suspended
  invitedAt    TEXT,
  joinedAt     TEXT,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_org_members_org ON organization_members(orgId);
CREATE INDEX IF NOT EXISTS idx_org_members_user ON organization_members(userId);
CREATE UNIQUE INDEX IF NOT EXISTS idx_org_member_unique ON organization_members(orgId, userId) WHERE userId IS NOT NULL;

CREATE TABLE IF NOT EXISTS custom_roles (
  id          TEXT PRIMARY KEY,
  orgId       TEXT NOT NULL,
  name        TEXT NOT NULL,
  permissions TEXT NOT NULL, -- JSON array of permission keys, e.g. ["agent_management","knowledge"]
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS workspaces (
  id          TEXT PRIMARY KEY,
  orgId       TEXT NOT NULL,
  name        TEXT NOT NULL,
  description TEXT,
  category    TEXT NOT NULL DEFAULT 'general', -- marketing|sales|support|finance|development|hr|general
  createdAt   TEXT NOT NULL,
  updatedAt   TEXT NOT NULL,
  FOREIGN KEY (orgId) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_workspaces_org ON workspaces(orgId);

CREATE TABLE IF NOT EXISTS workspace_members (
  id          TEXT PRIMARY KEY,
  workspaceId TEXT NOT NULL,
  userId      TEXT NOT NULL,
  role        TEXT NOT NULL DEFAULT 'member',
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (workspaceId) REFERENCES workspaces(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_workspace_member_unique ON workspace_members(workspaceId, userId);
`);

db.exec(`
CREATE TABLE IF NOT EXISTS agent_versions (
  id        TEXT PRIMARY KEY,
  agentId   TEXT NOT NULL,
  version   INTEGER NOT NULL,
  snapshot  TEXT NOT NULL, -- JSON: {name, description, instructions, personality, avatar, category, skillIds}
  note      TEXT,          -- optional human note, e.g. "cloned from Marketing Manager"
  createdAt TEXT NOT NULL,
  FOREIGN KEY (agentId) REFERENCES agents(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_agent_versions_agent ON agent_versions(agentId);

CREATE TABLE IF NOT EXISTS agent_messages (
  id             TEXT PRIMARY KEY,
  userId         TEXT NOT NULL,
  fromAgentId    TEXT NOT NULL,
  toAgentId      TEXT NOT NULL,
  type           TEXT NOT NULL DEFAULT 'delegate_task', -- ask | delegate_task | request_info | share_result | request_approval | return_output
  content        TEXT NOT NULL, -- the task/question sent to the target agent
  conversationId TEXT,          -- the conversation the target agent handled this in — reuses existing chat UI/history
  status         TEXT NOT NULL DEFAULT 'pending', -- pending | completed | failed
  result         TEXT,          -- the target agent's reply, once completed
  error          TEXT,
  createdAt      TEXT NOT NULL,
  completedAt    TEXT,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (fromAgentId) REFERENCES agents(id) ON DELETE CASCADE,
  FOREIGN KEY (toAgentId) REFERENCES agents(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_agent_messages_from ON agent_messages(fromAgentId);
CREATE INDEX IF NOT EXISTS idx_agent_messages_to ON agent_messages(toAgentId);
`);

// --- Seed the built-in skill registry (idempotent) ---
const seedSkills = [
  ["general-assistant", "General Assistant", "General-purpose AI assistance for planning, writing, reasoning, and everyday tasks.", "core"],
  ["research", "Research", "Search the web, read pages, and build cited research reports.", "knowledge"],
  ["content-creation", "Content Creation", "Draft posts, copy, and long-form content in a chosen voice.", "creative"],
  ["data-analysis", "Data Analysis", "Interpret tables and numbers and surface useful patterns.", "analytics"],
  ["marketing", "Marketing", "Plan campaigns, audiences, and messaging.", "growth"],
  ["productivity", "Productivity", "Organize tasks, schedules, and workflows.", "core"],
  ["memory", "Memory", "Remember and recall information across conversations.", "core"],
  ["meta_ads", "Meta Ads", "Manage Meta (Facebook/Instagram) ad campaigns once your account is connected.", "integration"],
  ["whatsapp", "WhatsApp Business", "Send and manage WhatsApp Business conversations once your account is connected.", "integration"],
  ["automations", "Automations", "Build and run automated workflows across your other skills and tools.", "core"],
  ["wordpress", "WordPress", "Manage posts, pages, and media on your WordPress site once connected.", "integration"],
  ["woocommerce", "WooCommerce", "Manage products, orders, and customers on your WooCommerce store once connected.", "integration"],
  ["gmail", "Gmail", "Read, search, and send email once your Gmail account is connected.", "integration"],
  ["calendar", "Google Calendar", "View and manage calendar events once your Google account is connected.", "integration"],
  ["drive", "Google Drive", "List, search, create, and share Drive files once your Google account is connected.", "integration"],
  ["docs", "Google Docs", "Create, read, and edit Google Docs once your Google account is connected.", "integration"],
  ["sheets", "Google Sheets", "Create spreadsheets and read/write cell data once your Google account is connected.", "integration"],
  ["shopify", "Shopify", "Manage products, orders, customers, inventory, discounts, and collections once your store is connected.", "integration"],
  ["collaboration", "Agent Collaboration", "Delegate tasks to your other agents and chain them together on multi-step work.", "core"],
];
const insertSkill = db.prepare(
  "INSERT OR IGNORE INTO skills (id, name, description, category, status) VALUES (?, ?, ?, ?, 'available')"
);
for (const s of seedSkills) insertSkill.run(...s);
// INSERT OR IGNORE won't touch a row that already exists (e.g. from an
// earlier phase's seed), so explicitly refresh descriptions on every boot.
const refreshSkill = db.prepare("UPDATE skills SET description = ?, category = ? WHERE id = ?");
for (const [id, , description, category] of seedSkills) refreshSkill.run(description, category, id);

// --- Seed starter workflow templates (idempotent, refreshed each boot) ---
const insertTemplate = db.prepare(
  "INSERT OR IGNORE INTO workflow_templates (id, name, description, category, triggerType, triggerConfig, steps) VALUES (?, ?, ?, ?, ?, ?, ?)"
);
const daily9am = JSON.stringify({ frequency: "daily", hour: 9, minute: 0 });
const seedTemplates = [
  [
    "tmpl-morning-report", "Morning Business Report",
    "Summarizes tasks, campaigns, and recent activity every morning.",
    "reporting", "schedule", daily9am,
    JSON.stringify([
      { type: "action", config: { toolName: "list_tasks", parameters: { status: "todo" }, resultVariable: "openTasks" } },
      { type: "action", config: { toolName: "list_campaigns", parameters: {}, resultVariable: "campaigns" } },
    ]),
  ],
  [
    "tmpl-meta-summary", "Daily Meta Ads Summary",
    "Pulls campaign insights and reports on ad performance daily.",
    "marketing", "schedule", daily9am,
    JSON.stringify([{ type: "action", config: { toolName: "list_campaigns", parameters: {}, resultVariable: "campaigns" } }]),
  ],
  [
    "tmpl-research-trending", "Research Trending Products",
    "Runs a web research pass on a topic and saves the findings.",
    "research", "manual", "{}",
    JSON.stringify([
      { type: "action", config: { toolName: "web_search", parameters: { query: "{{topic}}" }, resultVariable: "searchResults" } },
      { type: "action", config: { toolName: "generate_report", parameters: { topic: "{{topic}}", findings: "{{searchResults.results}}" }, resultVariable: "report" } },
      { type: "approval", config: { reason: "Save this research to your Knowledge Library?" } },
      { type: "action", config: { toolName: "save_research", parameters: { title: "{{topic}}", content: "{{report.report}}" } } },
    ]),
  ],
  [
    "tmpl-whatsapp-autoreply", "WhatsApp Auto Reply",
    "Replies to an incoming WhatsApp message using the connected agent.",
    "messaging", "manual", "{}",
    JSON.stringify([{ type: "action", config: { toolName: "reply_whatsapp_message", parameters: { to: "{{contactPhone}}", message: "{{replyText}}" } } }]),
  ],
  [
    "tmpl-lead-followup", "Lead Follow-up",
    "Creates a follow-up task and drafts an outreach message for a new lead.",
    "sales", "manual", "{}",
    JSON.stringify([
      { type: "action", config: { toolName: "create_task", parameters: { title: "Follow up: {{leadName}}", priority: "high" }, resultVariable: "task" } },
    ]),
  ],
  [
    "tmpl-customer-support", "Customer Support Assistant",
    "Answers a customer question and logs it as a task if it needs follow-up.",
    "support", "manual", "{}",
    JSON.stringify([
      { type: "ai_decision", config: { question: "Does this question need human follow-up? {{question}}", options: ["yes", "no"], resultVariable: "needsFollowup" } },
      { type: "condition", config: { groups: [[{ field: "{{needsFollowup.choice}}", op: "equals", value: "yes" }]], onFalse: "end" } },
      { type: "action", config: { toolName: "create_task", parameters: { title: "Follow up on support question", description: "{{question}}" } } },
    ]),
  ],
  [
    "tmpl-competitor-monitoring", "Competitor Monitoring",
    "Researches a competitor's recent activity on a schedule.",
    "research", "schedule", JSON.stringify({ frequency: "weekly", dayOfWeek: 1, hour: 9, minute: 0 }),
    JSON.stringify([
      { type: "action", config: { toolName: "web_search", parameters: { query: "{{competitor}} news this week" }, resultVariable: "searchResults" } },
      { type: "action", config: { toolName: "generate_report", parameters: { topic: "{{competitor}}", findings: "{{searchResults.results}}" }, resultVariable: "report" } },
    ]),
  ],
  [
    "tmpl-weekly-marketing", "Weekly Marketing Report",
    "Compiles campaign performance into a weekly summary.",
    "marketing", "schedule", JSON.stringify({ frequency: "weekly", dayOfWeek: 1, hour: 9, minute: 0 }),
    JSON.stringify([{ type: "action", config: { toolName: "list_campaigns", parameters: {}, resultVariable: "campaigns" } }]),
  ],
];
for (const t of seedTemplates) insertTemplate.run(...t);

// One-time backfill: agents created before the Memory skill existed (or
// created without picking any skill) have zero rows in agent_skills, so no
// tool is ever available to them. Grant the core set so existing agents
// gain tool access without the user having to delete and recreate them.
const agentsWithNoSkills = db.prepare(
  `SELECT id FROM agents WHERE id NOT IN (SELECT DISTINCT agentId FROM agent_skills)`
).all();
const grantSkill = db.prepare("INSERT OR IGNORE INTO agent_skills (agentId, skillId) VALUES (?, ?)");
for (const { id } of agentsWithNoSkills) {
  grantSkill.run(id, "general-assistant");
  grantSkill.run(id, "productivity");
  grantSkill.run(id, "memory");
}

export default db;
