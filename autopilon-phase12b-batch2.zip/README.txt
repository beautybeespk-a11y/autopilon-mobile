PHASE 12B — BATCH 2: Chat, Agents, Tasks, Notifications
==========================================================

WHAT'S IN HERE
--------------
Four feature folders, each following the same data/providers/presentation
pattern as the Dashboard batch and your existing organizations feature:

  chat/           — Chat.jsx equivalent: conversation drawer, agent picker,
                    message thread, tool-call trace, approval/confirmation
                    cards for sensitive actions (campaigns, delete_memory,
                    delete_saved_research), composer.
  agents/         — Agents.jsx equivalent: agent list, activate/deactivate,
                    clone, delete, publish-to-marketplace dialog. "New
                    agent" and "Edit" open a snackbar saying that's a later
                    phase — I didn't have AgentBuilder.jsx's source, so I
                    didn't attempt to build that screen blind.
  tasks/          — Tasks.jsx equivalent: task list, add task, per-task
                    comment thread (expand/collapse).
  notifications/  — NotificationBell.jsx equivalent: bell icon with unread
                    badge in the app bar, opens a bottom sheet (a dropdown
                    doesn't translate to mobile) with the same content:
                    mark-all-read, list, empty state, tap-to-open, 30s
                    polling (no websockets, matching the web client).

No Projects feature is included — I searched and didn't find a Projects
page in your web client at all, so there's nothing to mirror yet.

HOW TO INSTALL
---------------
1. Unzip this on your computer.
2. In VS Code Explorer, right-click "features" → Upload Folder, and
   upload each of the four folders (chat, agents, tasks, notifications)
   so they land at:
     /workspaces/autopilon_mobile/lib/features/chat/
     /workspaces/autopilon_mobile/lib/features/agents/
     /workspaces/autopilon_mobile/lib/features/tasks/
     /workspaces/autopilon_mobile/lib/features/notifications/
3. You'll also need to WIRE THESE INTO YOUR NAVIGATION — I don't have your
   router/shell file, so I couldn't add routes or nav-bar entries myself.
   Tell me what your bottom nav / router file looks like (or paste it)
   and I'll give you the exact lines to add, OR just add these three
   lines yourself in whatever file defines your go_router routes:
     GoRoute(path: '/chat', builder: (c, s) => const ChatScreen()),
     GoRoute(path: '/agents', builder: (c, s) => const AgentsScreen()),
     GoRoute(path: '/tasks', builder: (c, s) => const TasksScreen()),
   and add `const NotificationBellButton()` as an AppBar action wherever
   your shell's top bar is built.
4. Rebuild:
     cd /workspaces/autopilon_mobile
     flutter build apk --debug > build_log.txt 2>&1
     tail -30 build_log.txt

THINGS I ASSUMED — CHECK THESE FIRST IF THE BUILD FAILS
----------------------------------------------------------
I matched the exact ApiClient/ApiResult pattern from your
organization_repository.dart (get<T> with a parse callback, ApiResult
with .isSuccess/.data/.error). Three things I could NOT verify because I
haven't seen your ApiClient source directly:

1. POST/PATCH/DELETE method signatures. I assumed:
     Future<ApiResult<T>> post<T>(String path, {required Map body, required T Function(dynamic) parse})
     Future<ApiResult<T>> patch<T>(String path, {required Map body, required T Function(dynamic) parse})
     Future<ApiResult<void>> delete(String path)
   If the build errors on any of these (wrong argument names, missing
   method), send me the error and the actual method signature from
   api_client.dart and I'll fix the repository files.

2. ApiResult.statusCode — used in chat_repository.dart to detect a 409/410
   "already resolved" response for confirmations. If ApiResult doesn't
   have a statusCode field, tell me what it's actually called (or paste
   the ApiResult class) and I'll adjust.

3. Backend response shapes for /chat/message, /notifications, and the
   confirmation endpoints — I only saw the JSX consuming them, not the
   raw JSON. Field names in the model classes are my best guess from
   variable names in the JSX (e.g. d.reply, d.trace, d.confirmation).
   If data shows up blank/wrong, send me:
     curl -s https://YOUR-NGROK-URL/api/chat/conversations
   and I'll correct the models.

4. ToolActivity.jsx (renders the trace) wasn't part of what I could pull
   from your codebase, so _ToolTrace in chat_screen.dart is a generic
   fallback renderer, not a pixel-match. If you want it to look exactly
   like the web version, send me ToolActivity.jsx and I'll rebuild it.

Same as before — screenshot any build errors and I'll patch the zip.
