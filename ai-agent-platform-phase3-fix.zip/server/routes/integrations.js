import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../middleware.js";

const router = Router();
router.use(requireAuth);

// Catalog of integrations the platform will support. status here is the real,
// per-user connection status — nothing is faked as connected.
const CATALOG = [
  { provider: "meta_ads", name: "Meta Ads", note: "Priority integration", available: false },
  { provider: "gmail", name: "Gmail", available: false },
  { provider: "google_calendar", name: "Google Calendar", available: false },
  { provider: "google_drive", name: "Google Drive", available: false },
  { provider: "wordpress", name: "WordPress", available: false },
  { provider: "woocommerce", name: "WooCommerce", available: false },
  { provider: "shopify", name: "Shopify", available: false },
  { provider: "slack", name: "Slack", available: false },
  { provider: "telegram", name: "Telegram", available: false },
];

router.get("/", (req, res) => {
  const mine = db.prepare("SELECT provider, status FROM integrations WHERE userId = ?").all(req.session.userId);
  const map = Object.fromEntries(mine.map((r) => [r.provider, r.status]));
  res.json(CATALOG.map((c) => ({ ...c, status: map[c.provider] || "not_connected" })));
});

export default router;
