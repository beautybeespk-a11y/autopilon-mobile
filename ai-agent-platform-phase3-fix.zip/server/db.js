import Database from "better-sqlite3";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const db = new Database(join(__dirname, "app.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// --- Schema. Extend by adding tables/columns; keep migrations additive. ---
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL UNIQUE,
  password   TEXT NOT NULL,
  avatar     TEXT,
  createdAt  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agents (
  id           TEXT PRIMARY KEY,
  userId       TEXT NOT NULL,
  name         TEXT NOT NULL,
  description  TEXT,
  instructions TEXT,
  personality  TEXT DEFAULT 'professional',
  status       TEXT DEFAULT 'active',
  createdAt    TEXT NOT NULL,
  updatedAt    TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_agents_user ON agents(userId);

CREATE TABLE IF NOT EXISTS skills (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT,
  category    TEXT,
  status      TEXT DEFAULT 'available'
);

CREATE TABLE IF NOT EXISTS agent_skills (
  agentId TEXT NOT NULL,
  skillId TEXT NOT NULL,
  PRIMARY KEY (agentId, skillId),
  FOREIGN KEY (agentId) REFERENCES agents(id) ON DELETE CASCADE,
  FOREIGN KEY (skillId) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conversations (
  id         TEXT PRIMARY KEY,
  userId     TEXT NOT NULL,
  agentId    TEXT,
  title      TEXT NOT NULL DEFAULT 'New conversation',
  createdAt  TEXT NOT NULL,
  updatedAt  TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(userId);

CREATE TABLE IF NOT EXISTS messages (
  id             TEXT PRIMARY KEY,
  conversationId TEXT NOT NULL,
  role           TEXT NOT NULL,
  content        TEXT NOT NULL,
  createdAt      TEXT NOT NULL,
  FOREIGN KEY (conversationId) REFERENCES conversations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversationId);

CREATE TABLE IF NOT EXISTS memories (
  id        TEXT PRIMARY KEY,
  userId    TEXT NOT NULL,
  content   TEXT NOT NULL,
  type      TEXT DEFAULT 'note',
  createdAt TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_mem_user ON memories(userId);

CREATE TABLE IF NOT EXISTS integrations (
  id        TEXT PRIMARY KEY,
  userId    TEXT NOT NULL,
  provider  TEXT NOT NULL,
  status    TEXT DEFAULT 'not_connected',
  createdAt TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_int_user ON integrations(userId);

CREATE TABLE IF NOT EXISTS tasks (
  id          TEXT PRIMARY KEY,
  userId      TEXT NOT NULL,
  title       TEXT NOT NULL,
  description TEXT,
  status      TEXT DEFAULT 'todo',
  priority    TEXT DEFAULT 'medium',
  dueDate     TEXT,
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(userId);

CREATE TABLE IF NOT EXISTS activity_logs (
  id          TEXT PRIMARY KEY,
  userId      TEXT NOT NULL,
  action      TEXT NOT NULL,
  description TEXT,
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_act_user ON activity_logs(userId);

-- ---- Phase 2: Orchestrator / Tool execution ----

CREATE TABLE IF NOT EXISTS execution_plans (
  id             TEXT PRIMARY KEY,
  userId         TEXT NOT NULL,
  conversationId TEXT,
  goal           TEXT,
  status         TEXT NOT NULL DEFAULT 'planning', -- planning|running|completed|failed
  createdAt      TEXT NOT NULL,
  updatedAt      TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_plans_user ON execution_plans(userId);

CREATE TABLE IF NOT EXISTS tool_executions (
  id             TEXT PRIMARY KEY,
  planId         TEXT,
  userId         TEXT NOT NULL,
  conversationId TEXT,
  toolName       TEXT NOT NULL,
  parameters     TEXT, -- JSON string; never store secrets here
  status         TEXT NOT NULL DEFAULT 'pending', -- pending|planning|awaiting_confirmation|running|completed|failed
  result         TEXT, -- JSON string
  error          TEXT,
  startedAt      TEXT,
  completedAt    TEXT,
  createdAt      TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (planId) REFERENCES execution_plans(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_exec_user ON tool_executions(userId);
CREATE INDEX IF NOT EXISTS idx_exec_plan ON tool_executions(planId);

CREATE TABLE IF NOT EXISTS confirmation_requests (
  id          TEXT PRIMARY KEY,
  executionId TEXT NOT NULL,
  userId      TEXT NOT NULL,
  toolName    TEXT NOT NULL,
  reason      TEXT,
  status      TEXT NOT NULL DEFAULT 'pending', -- pending|approved|rejected|expired
  createdAt   TEXT NOT NULL,
  resolvedAt  TEXT,
  expiresAt   TEXT NOT NULL,
  FOREIGN KEY (executionId) REFERENCES tool_executions(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_confirm_user ON confirmation_requests(userId);
CREATE INDEX IF NOT EXISTS idx_confirm_exec ON confirmation_requests(executionId);

-- Per-agent skill→permission grants. Phase 1 seeded agent_skills already
-- controls which skills an agent has; this table is for future per-agent
-- permission overrides. Not required for Phase 2's default (skill grants
-- imply its tools' permissions) but present so the schema doesn't need
-- another migration when fine-grained control is added.
CREATE TABLE IF NOT EXISTS agent_permissions (
  agentId    TEXT NOT NULL,
  permission TEXT NOT NULL,
  PRIMARY KEY (agentId, permission),
  FOREIGN KEY (agentId) REFERENCES agents(id) ON DELETE CASCADE
);

-- ---- Phase 3: Web research & Knowledge Library ----
-- One flexible table backs the Knowledge Library (reports, notes, saved
-- URLs, summaries) — same shape (title/content/tags/sources/owner/date)
-- regardless of type, so one table with a discriminator beats four
-- near-duplicate ones. "Research History" is served by the tool_executions
-- table already built in Phase 2 (every web_search/read_webpage/etc. call
-- is already logged there per user, per conversation, with a timestamp).
CREATE TABLE IF NOT EXISTS knowledge_items (
  id         TEXT PRIMARY KEY,
  userId     TEXT NOT NULL,
  type       TEXT NOT NULL DEFAULT 'report', -- report|note|url|summary|article
  title      TEXT NOT NULL,
  category   TEXT,
  tags       TEXT, -- JSON array
  content    TEXT, -- JSON: report object or { note }
  sourceUrls TEXT, -- JSON array of { title, url }
  createdAt  TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_knowledge_user ON knowledge_items(userId);
`);

// Additive migration: messages.meta stores JSON trace/toolResults for
// assistant messages so the ToolActivity rail survives a page refresh.
const messageCols = db.prepare("PRAGMA table_info(messages)").all().map((c) => c.name);
if (!messageCols.includes("meta")) {
  db.exec("ALTER TABLE messages ADD COLUMN meta TEXT");
}

// --- Seed the built-in skill registry (idempotent) ---
const seedSkills = [
  ["general-assistant", "General Assistant", "General-purpose AI assistance for planning, writing, reasoning, and everyday tasks.", "core"],
  ["research", "Research", "Search the web, read pages, and build cited research reports.", "knowledge"],
  ["content-creation", "Content Creation", "Draft posts, copy, and long-form content in a chosen voice.", "creative"],
  ["data-analysis", "Data Analysis", "Interpret tables and numbers and surface useful patterns.", "analytics"],
  ["marketing", "Marketing", "Plan campaigns, audiences, and messaging.", "growth"],
  ["productivity", "Productivity", "Organize tasks, schedules, and workflows.", "core"],
  ["memory", "Memory", "Remember and recall information across conversations.", "core"],
];
const insertSkill = db.prepare(
  "INSERT OR IGNORE INTO skills (id, name, description, category, status) VALUES (?, ?, ?, ?, 'available')"
);
for (const s of seedSkills) insertSkill.run(...s);
// INSERT OR IGNORE won't touch a row that already exists (e.g. from an
// earlier phase's seed), so explicitly refresh descriptions on every boot.
const refreshSkill = db.prepare("UPDATE skills SET description = ?, category = ? WHERE id = ?");
for (const [id, , description, category] of seedSkills) refreshSkill.run(description, category, id);

// One-time backfill: agents created before the Memory skill existed (or
// created without picking any skill) have zero rows in agent_skills, so no
// tool is ever available to them. Grant the core set so existing agents
// gain tool access without the user having to delete and recreate them.
const agentsWithNoSkills = db.prepare(
  `SELECT id FROM agents WHERE id NOT IN (SELECT DISTINCT agentId FROM agent_skills)`
).all();
const grantSkill = db.prepare("INSERT OR IGNORE INTO agent_skills (agentId, skillId) VALUES (?, ?)");
for (const { id } of agentsWithNoSkills) {
  grantSkill.run(id, "general-assistant");
  grantSkill.run(id, "productivity");
  grantSkill.run(id, "memory");
}

export default db;
