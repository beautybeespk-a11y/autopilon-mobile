import { useEffect, useState } from "react";
import * as Icons from "lucide-react";
import { Card, Badge, Button } from "../components/ui/index.jsx";
import { api } from "../lib/api.js";

const ICON = {
  meta_ads: "Megaphone", gmail: "Mail", google_calendar: "Calendar", google_drive: "HardDrive",
  wordpress: "Globe", woocommerce: "ShoppingCart", shopify: "ShoppingBag", slack: "MessageSquare", telegram: "Send",
};

export default function Integrations() {
  const [items, setItems] = useState([]);
  useEffect(() => { api.get("/integrations").then(setItems).catch(() => {}); }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Integrations</h1>
        <p className="mt-1 text-muted">Connect the tools your agents work with. Nothing is connected until a real connection is made.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => {
          const Icon = Icons[ICON[it.provider]] || Icons.Puzzle;
          const connected = it.status === "connected";
          return (
            <Card key={it.provider} className="p-5">
              <div className="mb-3 flex items-center justify-between">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-elevated text-ink"><Icon size={20} /></div>
                {it.note && <Badge tone="accent">{it.note}</Badge>}
              </div>
              <h3 className="font-display font-semibold">{it.name}</h3>
              <div className="mt-1">
                {connected ? <Badge tone="success">Connected</Badge> : <Badge>Not connected</Badge>}
              </div>
              <div className="mt-4">
                {it.available ? (
                  <Button variant="outline" className="w-full">Connect</Button>
                ) : (
                  <Button variant="subtle" className="w-full" disabled>Coming soon</Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
