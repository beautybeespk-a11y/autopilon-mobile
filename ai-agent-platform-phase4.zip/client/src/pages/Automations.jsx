import { Zap } from "lucide-react";
import { EmptyState, Button } from "../components/ui/index.jsx";

export default function Automations() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Automations</h1>
        <p className="mt-1 text-muted">Run agents on a schedule or in response to events.</p>
      </div>
      <EmptyState
        icon={Zap}
        title="Automations arrive in a later phase"
        description="Once triggers and actions are connected, you'll build routines here — like a daily report or an agent that reacts to new email."
        action={<Button variant="outline" to="/app/agents/new">Create an agent first</Button>}
      />
    </div>
  );
}
