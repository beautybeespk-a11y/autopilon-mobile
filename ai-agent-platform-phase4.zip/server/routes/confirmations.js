import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../middleware.js";
import { resumeAfterConfirmation } from "../orchestrator/executor.js";

const router = Router();
router.use(requireAuth);

function loadOwnedConfirmation(id, userId) {
  return db.prepare("SELECT * FROM confirmation_requests WHERE id = ? AND userId = ?").get(id, userId);
}

router.post("/:id/approve", async (req, res) => resolve(req, res, true));
router.post("/:id/reject", async (req, res) => resolve(req, res, false));

async function resolve(req, res, approved) {
  const confirmation = loadOwnedConfirmation(req.params.id, req.session.userId);
  if (!confirmation) return res.status(404).json({ error: "Confirmation not found" });
  if (confirmation.status !== "pending") {
    return res.status(409).json({ error: `This confirmation was already ${confirmation.status}.` });
  }
  if (new Date(confirmation.expiresAt) < new Date()) {
    db.prepare("UPDATE confirmation_requests SET status = 'expired', resolvedAt = ? WHERE id = ?").run(new Date().toISOString(), confirmation.id);
    return res.status(410).json({ error: "This confirmation has expired." });
  }

  db.prepare("UPDATE confirmation_requests SET status = ?, resolvedAt = ? WHERE id = ?")
    .run(approved ? "approved" : "rejected", new Date().toISOString(), confirmation.id);

  try {
    const outcome = await resumeAfterConfirmation({ executionId: confirmation.executionId, approved });
    res.json({ confirmationId: confirmation.id, ...outcome });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export default router;
