import Database from "better-sqlite3";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const db = new Database(join(__dirname, "app.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// --- Schema. Extend by adding tables/columns; keep migrations additive. ---
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL UNIQUE,
  password   TEXT NOT NULL,
  avatar     TEXT,
  createdAt  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agents (
  id           TEXT PRIMARY KEY,
  userId       TEXT NOT NULL,
  name         TEXT NOT NULL,
  description  TEXT,
  instructions TEXT,
  personality  TEXT DEFAULT 'professional',
  status       TEXT DEFAULT 'active',
  createdAt    TEXT NOT NULL,
  updatedAt    TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_agents_user ON agents(userId);

CREATE TABLE IF NOT EXISTS skills (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT,
  category    TEXT,
  status      TEXT DEFAULT 'available'
);

CREATE TABLE IF NOT EXISTS agent_skills (
  agentId TEXT NOT NULL,
  skillId TEXT NOT NULL,
  PRIMARY KEY (agentId, skillId),
  FOREIGN KEY (agentId) REFERENCES agents(id) ON DELETE CASCADE,
  FOREIGN KEY (skillId) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conversations (
  id         TEXT PRIMARY KEY,
  userId     TEXT NOT NULL,
  agentId    TEXT,
  title      TEXT NOT NULL DEFAULT 'New conversation',
  createdAt  TEXT NOT NULL,
  updatedAt  TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(userId);

CREATE TABLE IF NOT EXISTS messages (
  id             TEXT PRIMARY KEY,
  conversationId TEXT NOT NULL,
  role           TEXT NOT NULL,
  content        TEXT NOT NULL,
  createdAt      TEXT NOT NULL,
  FOREIGN KEY (conversationId) REFERENCES conversations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversationId);

CREATE TABLE IF NOT EXISTS memories (
  id        TEXT PRIMARY KEY,
  userId    TEXT NOT NULL,
  content   TEXT NOT NULL,
  type      TEXT DEFAULT 'note',
  createdAt TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_mem_user ON memories(userId);

CREATE TABLE IF NOT EXISTS integrations (
  id        TEXT PRIMARY KEY,
  userId    TEXT NOT NULL,
  provider  TEXT NOT NULL,
  status    TEXT DEFAULT 'not_connected',
  createdAt TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_int_user ON integrations(userId);

CREATE TABLE IF NOT EXISTS tasks (
  id          TEXT PRIMARY KEY,
  userId      TEXT NOT NULL,
  title       TEXT NOT NULL,
  description TEXT,
  status      TEXT DEFAULT 'todo',
  priority    TEXT DEFAULT 'medium',
  dueDate     TEXT,
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(userId);

CREATE TABLE IF NOT EXISTS activity_logs (
  id          TEXT PRIMARY KEY,
  userId      TEXT NOT NULL,
  action      TEXT NOT NULL,
  description TEXT,
  createdAt   TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_act_user ON activity_logs(userId);
`);

// --- Seed the built-in skill registry (idempotent) ---
const seedSkills = [
  ["general-assistant", "General Assistant", "General-purpose AI assistance for planning, writing, reasoning, and everyday tasks.", "core"],
  ["research", "Research", "Gather, compare, and summarize information from provided context.", "knowledge"],
  ["content-creation", "Content Creation", "Draft posts, copy, and long-form content in a chosen voice.", "creative"],
  ["data-analysis", "Data Analysis", "Interpret tables and numbers and surface useful patterns.", "analytics"],
  ["marketing", "Marketing", "Plan campaigns, audiences, and messaging.", "growth"],
  ["productivity", "Productivity", "Organize tasks, schedules, and workflows.", "core"],
];
const insertSkill = db.prepare(
  "INSERT OR IGNORE INTO skills (id, name, description, category, status) VALUES (?, ?, ?, ?, 'available')"
);
for (const s of seedSkills) insertSkill.run(...s);

export default db;
