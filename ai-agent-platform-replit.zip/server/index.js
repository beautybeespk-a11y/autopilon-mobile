import "dotenv/config";
import express from "express";
import session from "express-session";
import cors from "cors";
import ConnectSqlite3 from "connect-sqlite3";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import fs from "fs";

import "./db.js";
import authRoutes from "./routes/auth.js";
import chatRoutes from "./routes/chat.js";
import agentRoutes from "./routes/agents.js";
import skillRoutes from "./routes/skills.js";
import integrationRoutes from "./routes/integrations.js";
import taskRoutes from "./routes/tasks.js";
import activityRoutes from "./routes/activity.js";
import dashboardRoutes from "./routes/dashboard.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;
const SQLiteStore = ConnectSqlite3(session);

app.use(express.json({ limit: "2mb" }));

// In dev the client runs on :5173 and proxies /api, so CORS with credentials
// is only needed if you point the client at the server cross-origin.
app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN || true,
    credentials: true,
  })
);

app.use(
  session({
    store: new SQLiteStore({ db: "sessions.sqlite", dir: __dirname }),
    secret: process.env.SESSION_SECRET || "dev-insecure-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 1000 * 60 * 60 * 24 * 7,
    },
  })
);

app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use("/api/auth", authRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/agents", agentRoutes);
app.use("/api/skills", skillRoutes);
app.use("/api/integrations", integrationRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/dashboard", dashboardRoutes);

// Serve the built client in production (single-service deploy).
const clientDist = join(__dirname, "..", "client", "dist");
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api")) return res.status(404).json({ error: "Not found" });
    res.sendFile(join(clientDist, "index.html"));
  });
}

app.listen(PORT, () => {
  console.log(`AI Agent Platform API running on http://localhost:${PORT}`);
});
