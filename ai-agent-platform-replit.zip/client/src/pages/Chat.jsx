import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import { Plus, Send, Paperclip, Mic, Square, Sparkles, AlertTriangle } from "lucide-react";
import { api } from "../lib/api.js";

const SUGGESTED = ["Draft a launch plan for a new product", "Summarize the key risks in a project", "Brainstorm names for an AI agent"];

export default function Chat() {
  const location = useLocation();
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [providerErr, setProviderErr] = useState(null);
  const scrollRef = useRef(null);

  const loadConversations = () => api.get("/chat/conversations").then(setConversations).catch(() => {});

  useEffect(() => {
    loadConversations();
    // If arriving from the dashboard quick prompt, send it immediately.
    if (location.state?.prompt) send(location.state.prompt);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight); }, [messages, sending]);

  const openConversation = async (id) => {
    setActiveId(id);
    const d = await api.get(`/chat/conversations/${id}/messages`);
    setMessages(d.messages);
  };

  const newConversation = () => { setActiveId(null); setMessages([]); setProviderErr(null); };

  const send = async (text) => {
    const content = (text ?? input).trim();
    if (!content || sending) return;
    setInput("");
    setProviderErr(null);
    setMessages((m) => [...m, { id: "tmp-" + Date.now(), role: "user", content }]);
    setSending(true);
    try {
      const d = await api.post("/chat/message", { conversationId: activeId, content });
      setActiveId(d.conversationId);
      setMessages((m) => [...m, { id: "a-" + Date.now(), role: "assistant", content: d.reply }]);
      loadConversations();
    } catch (err) {
      if (err.status === 503) setProviderErr(err.detail || "AI provider not configured");
      else setProviderErr(err.message);
      if (err.data?.conversationId) setActiveId(err.data.conversationId);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-8.5rem)] gap-4 md:h-[calc(100vh-9rem)]">
      {/* History */}
      <div className="hidden w-60 shrink-0 flex-col rounded-2xl border border-line bg-surface p-3 lg:flex">
        <button onClick={newConversation} className="mb-3 flex items-center gap-2 rounded-xl accent-gradient px-3 py-2.5 text-sm font-medium text-white">
          <Plus size={16} /> New conversation
        </button>
        <div className="flex-1 space-y-1 overflow-y-auto">
          {conversations.length === 0 && <p className="px-2 py-3 text-xs text-muted">No conversations yet.</p>}
          {conversations.map((c) => (
            <button
              key={c.id}
              onClick={() => openConversation(c.id)}
              className={`w-full truncate rounded-lg px-3 py-2 text-left text-sm ${activeId === c.id ? "bg-accent/10 text-accent" : "text-muted hover:bg-elevated hover:text-ink"}`}
            >
              {c.title}
            </button>
          ))}
        </div>
      </div>

      {/* Thread */}
      <div className="flex min-w-0 flex-1 flex-col rounded-2xl border border-line bg-surface">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-6">
          {messages.length === 0 && !sending ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-4 grid h-14 w-14 place-items-center rounded-2xl accent-gradient text-white shadow-glow"><Sparkles size={26} /></div>
              <h2 className="font-display text-xl font-semibold">Your AI workspace starts here.</h2>
              <p className="mt-2 max-w-sm text-sm text-muted">Ask questions, create plans, analyze information, and get things done.</p>
              <div className="mt-6 flex flex-col gap-2">
                {SUGGESTED.map((s) => (
                  <button key={s} onClick={() => send(s)} className="rounded-xl border border-line px-4 py-2.5 text-sm text-muted hover:border-accent/40 hover:text-ink">{s}</button>
                ))}
              </div>
            </div>
          ) : (
            <div className="mx-auto max-w-2xl space-y-5">
              {messages.map((m) => (
                <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm ${m.role === "user" ? "accent-gradient text-white" : "border border-line bg-elevated text-ink"}`}>
                    {m.content}
                  </div>
                </div>
              ))}
              {sending && (
                <div className="flex justify-start">
                  <div className="rounded-2xl border border-line bg-elevated px-4 py-3">
                    <span className="flex gap-1">
                      <span className="h-2 w-2 animate-bounce rounded-full bg-muted [animation-delay:-0.2s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-muted [animation-delay:-0.1s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-muted" />
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {providerErr && (
          <div className="mx-4 mb-2 flex items-center gap-2 rounded-xl border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-sm text-amber-500">
            <AlertTriangle size={16} /> AI provider not configured — {providerErr}
          </div>
        )}

        {/* Composer */}
        <div className="border-t border-line p-3">
          <div className="flex items-end gap-2 rounded-2xl border border-line bg-bg px-3 py-2">
            <button className="rounded-lg p-2 text-muted hover:bg-elevated" title="Attach file (coming soon)" disabled><Paperclip size={18} /></button>
            <button className="rounded-lg p-2 text-muted hover:bg-elevated" title="Voice input (coming soon)" disabled><Mic size={18} /></button>
            <textarea
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder="Message your assistant…"
              className="max-h-32 flex-1 resize-none bg-transparent py-2 text-sm outline-none"
            />
            {sending ? (
              <button className="rounded-xl bg-elevated p-2.5 text-muted" title="Stop"><Square size={16} /></button>
            ) : (
              <button onClick={() => send()} disabled={!input.trim()} className="rounded-xl accent-gradient p-2.5 text-white disabled:opacity-40"><Send size={16} /></button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
