HOW TO USE THIS ZIP
====================
1. Download and unzip this on your computer.
2. Upload the "dashboard" folder into:
   /workspaces/autopilon_mobile/lib/features/dashboard/
   (In VS Code: right-click "features" in Explorer -> Upload Folder,
   or drag-and-drop the "dashboard" folder onto "features" in Explorer.)
3. In your Codespace terminal, rebuild:
   cd /workspaces/autopilon_mobile
   flutter build apk --debug > build_log.txt 2>&1
   tail -30 build_log.txt

THINGS I ASSUMED (please check if the build fails on these)
==============================================================
I wrote these files by matching the exact patterns I could see in your
organization_repository.dart and organization_provider.dart screenshots.
Two things I could NOT see directly and had to assume:

1. In dashboard_provider.dart, I import:
     '../../auth/providers/auth_provider.dart'
   and use `apiClientProvider` from it. If your API client provider has
   a different name or lives in a different file, the build will show
   an error like "apiClientProvider isn't defined" — tell me the exact
   name/location and I'll fix it.

2. I assumed your ApiClient has a method shaped like:
     Future<ApiResult<T>> get<T>(String path, {required T Function(dynamic) parse})
   and that ApiResult has `.isSuccess`, `.data`, `.error` — this matched
   what I saw in organization_repository.dart. If dashboard_repository.dart
   errors on these, that's the mismatch to look at.

3. I don't know your backend's exact JSON field names for the dashboard/
   analytics/cost endpoints (I only saw the JSX consuming them, not the
   API response itself). The models use fairly safe defaults (0, empty
   list) for anything missing, so the screen shouldn't crash — but some
   numbers may show as 0 until we confirm the real field names. If that
   happens, run this in your Codespace terminal and send me the output:
     curl -s https://isotope-dipping-cobweb.ngrok-free.dev/api/organizations/YOUR_ORG_ID/dashboard

Just paste any build errors back to me as a screenshot like before and
I'll fix the zip.
