import db from "../db.js";
import { cryptoRandom } from "../middleware.js";
import { orchestrate } from "./index.js";

// Everything a new inbound message needs to go through, regardless of which
// channel it arrived on (web chat or WhatsApp): build the agent's system
// prompt, load + enrich history, run the Orchestrator, persist the reply.
// Both routes/chat.js and the WhatsApp webhook call this — neither
// duplicates it.
// Capped so a large attached file doesn't blow out the LLM's context window
// (or the API cost) on a single turn. The full text is still saved to the
// Knowledge Library by the upload endpoint, so nothing is lost — just not
// all of it is pasted into this one prompt.
const MAX_ATTACHMENT_CHARS = 8000;

export async function handleIncomingMessage({
  userId, agentId, conversationId, content, attachmentTitle = null, attachmentText = null, skipUserInsert = false,
}) {
  const now = new Date().toISOString();

  // What gets stored and shown in the chat transcript stays short — just a
  // 📎 marker and the user's own words. The full attachment text is only
  // added to what the LLM sees for THIS turn (below), not persisted into
  // the visible message, so re-opening the conversation later doesn't show
  // a wall of pasted file content.
  const displayContent = attachmentTitle ? `📎 ${attachmentTitle}${content?.trim() ? `\n\n${content}` : ""}` : content;

  if (!skipUserInsert) {
    db.prepare("INSERT INTO messages (id, conversationId, role, content, createdAt) VALUES (?, ?, 'user', ?, ?)")
      .run(cryptoRandom(), conversationId, displayContent, now);
  }

  // Passed to orchestrate() as `extraContext` — appended to what the MODEL
  // sees for this turn only (see orchestrator/index.js), not stored in the
  // DB. `history` below still reflects the short displayContent.
  let extraContext = null;
  if (attachmentText) {
    const truncated = attachmentText.length > MAX_ATTACHMENT_CHARS;
    const clipped = attachmentText.slice(0, MAX_ATTACHMENT_CHARS);
    extraContext =
      `[Attached file: "${attachmentTitle}". Contents:\n"""\n${clipped}` +
      `${truncated ? "\n[...truncated...]" : ""}\n"""]`;
  }

  let systemPrompt = "You are a helpful AI assistant inside the AI Agent Platform.";
  if (agentId) {
    const agent = db.prepare("SELECT * FROM agents WHERE id = ? AND userId = ?").get(agentId, userId);
    if (agent) systemPrompt = `You are "${agent.name}". Personality: ${agent.personality}. ${agent.instructions || ""}`.trim();
  }

  // Prior tool results are folded into history so a follow-up referencing an
  // earlier result by name (e.g. a campaign, a task) can still resolve back
  // to its real ID — see the Phase 4 cross-turn memory fix for why this matters.
  const rawHistory = db.prepare("SELECT role, content, meta FROM messages WHERE conversationId = ? ORDER BY createdAt ASC").all(conversationId);
  const history = rawHistory.map((m) => {
    if (m.role !== "assistant" || !m.meta) return { role: m.role, content: m.content };
    const parsedMeta = JSON.parse(m.meta);
    const successes = (parsedMeta.toolResults || []).filter((r) => !r.error);
    if (!successes.length) return { role: m.role, content: m.content };
    const dataNote = successes.map((r) => `${r.toolName} returned: ${JSON.stringify(r.result)}`).join("\n");
    return { role: m.role, content: `${m.content}\n\n[Underlying tool data from this turn, for your own reference in follow-ups — do not repeat verbatim: ${dataNote}]` };
  });

  const { reply, trace, toolResults, confirmation } = await orchestrate({
    userId,
    agentId: agentId || null,
    conversationId,
    userMessage: content || "",
    history,
    agentSystemPrompt: systemPrompt,
    extraContext,
  });

  const replyAt = new Date().toISOString();
  const meta = JSON.stringify({ trace, toolResults, confirmation });
  const assistantMessageId = cryptoRandom();
  db.prepare("INSERT INTO messages (id, conversationId, role, content, createdAt, meta) VALUES (?, ?, 'assistant', ?, ?, ?)")
    .run(assistantMessageId, conversationId, reply, replyAt, meta);
  db.prepare("UPDATE conversations SET updatedAt = ? WHERE id = ?").run(replyAt, conversationId);

  return { conversationId, reply, trace, toolResults, confirmation, assistantMessageId };
}
